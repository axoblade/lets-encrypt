import 'package:foodex_deliveryboy_app/pages/screen.dart';

class AvailableDelivery extends StatefulWidget {
  @override
  _AvailableDeliveryState createState() => _AvailableDeliveryState();
}

class _AvailableDeliveryState extends State<AvailableDelivery> {
  String isSelected = 'new';

  final newDeliveryList = [
    {
      'orderId': 'ACR147856',
      'paymentMethod': 'Online',
      'totalPayment': '\$32.00',
      'time': '1 min',
      'toAddress': '48, Hunters Road, Vepery',
      'fromAddress': 'Great Western, Mcc Lane, Fort',
    },
    {
      'orderId': ' AWQ145698',
      'paymentMethod': 'Cash on delivery',
      'totalPayment': '\$35.00',
      'time': '20 min',
      'toAddress': '491, Sai Section, Ambernath',
      'fromAddress': '21, 5th Cross Double Road...',
    },
    {
      'orderId': ' TRE123654',
      'paymentMethod': 'Online',
      'totalPayment': '\$40.00',
      'time': '45 min',
      'toAddress': '175 Jawahar Ngr, Amizara...',
      'fromAddress': 'Jaina Tower Distt Centre...',
    },
    {
      'orderId': 'TSA123698',
      'paymentMethod': 'Online',
      'totalPayment': '\$40.00',
      'time': '55 min',
      'toAddress': '48, Hunters Road, Vepery',
      'fromAddress': 'Great Western, Mcc Lane, Fort',
    },
    {
      'orderId': 'TSA123698',
      'paymentMethod': 'Online',
      'totalPayment': '\$40.00',
      'time': '1h',
      'toAddress': '48, Hunters Road, Vepery',
      'fromAddress': 'Great Western, Mcc Lane, Fort',
    },
  ];

  final activeDeliveryList = [
    {
      'orderId': 'ACR147856',
      'paymentMethod': 'Online',
      'totalPayment': '\$32.00',
      'toAddress': '48, Hunters Road, Vepery',
      'fromAddress': 'Great Western, Mcc Lane, Fort',
    },
    {
      'orderId': ' AWQ145698',
      'paymentMethod': 'Cash on delivery',
      'totalPayment': '\$35.00',
      'toAddress': '491, Sai Section, Ambernath',
      'fromAddress': '21, 5th Cross Double Road...',
    },
    {
      'orderId': ' TRE123654',
      'paymentMethod': 'Online',
      'totalPayment': '\$40.00',
      'toAddress': '175 Jawahar Ngr, Amizara...',
      'fromAddress': 'Jaina Tower Distt Centre...',
    },
    {
      'orderId': 'TSA123698',
      'paymentMethod': 'Online',
      'totalPayment': '\$40.00',
      'toAddress': '48, Hunters Road, Vepery',
      'fromAddress': 'Great Western, Mcc Lane, Fort',
    },
    {
      'orderId': 'TSA123698',
      'paymentMethod': 'Online',
      'totalPayment': '\$40.00',
      'toAddress': '48, Hunters Road, Vepery',
      'fromAddress': 'Great Western, Mcc Lane, Fort',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
        title: Text(
          'Available Deliveries',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: Column(
        children: [
          deliveryMenu(),
          isSelected == 'new' ? newDeliveriesList() : activeDeliveriesList(),
        ],
      ),
    );
  }

  deliveryMenu() {
    return Container(
      color: lightBlueColor,
      margin: EdgeInsets.only(
        top: fixPadding,
      ),
      padding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          InkWell(
            onTap: () {
              setState(() {
                isSelected = 'new';
              });
            },
            child: Container(
              padding: EdgeInsets.symmetric(
                vertical: fixPadding,
                horizontal: fixPadding * 2.0,
              ),
              decoration: BoxDecoration(
                border: isSelected == 'new'
                    ? Border(bottom: BorderSide(color: darkBlueColor))
                    : null,
              ),
              child: Text(
                'New Deliveries',
                style: darkBlueColor14SemiBoldTextStyle,
              ),
            ),
          ),
          InkWell(
            onTap: () {
              setState(() {
                isSelected = 'active';
              });
            },
            child: Container(
              padding: EdgeInsets.symmetric(
                vertical: fixPadding,
                horizontal: fixPadding * 2.0,
              ),
              decoration: BoxDecoration(
                border: isSelected == 'active'
                    ? Border(bottom: BorderSide(color: darkBlueColor))
                    : null,
              ),
              child: Text(
                'Active Deliveries',
                style: darkBlueColor14SemiBoldTextStyle,
              ),
            ),
          ),
        ],
      ),
    );
  }

  newDeliveriesList() {
    return Expanded(
      child: ListView.builder(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        itemCount: newDeliveryList.length,
        itemBuilder: (context, index) {
          final item = newDeliveryList[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(
              fixPadding * 2.0,
              index == 0 ? fixPadding * 2.0 : fixPadding,
              fixPadding * 2.0,
              fixPadding,
            ),
            child: InkWell(
              onTap: () => newOrderDetails(),
              child: Container(
                decoration: BoxDecoration(
                  color: lightBlueColor,
                  borderRadius: BorderRadius.circular(10.0),
                  boxShadow: [
                    BoxShadow(
                      color: greyColor.withOpacity(0.1),
                      spreadRadius: 2.5,
                      blurRadius: 2.5,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(5.0),
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          topRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            height: 45.0,
                            width: 35.0,
                            color: whiteColor,
                            child: Image.asset(
                              'assets/icons/order_food.png',
                              color: darkBlueColor,
                            ),
                          ),
                          widthSpace,
                          widthSpace,
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          'Order ID: ',
                                          style: greyColor12MediumTextStyle,
                                        ),
                                        Text(
                                          item['orderId'],
                                          style:
                                              darkBlueColor14SemiBoldTextStyle,
                                        ),
                                      ],
                                    ),
                                    Row(
                                      children: [
                                        Text(
                                          item['time'],
                                          style: greyColor9MediumTextStyle,
                                        ),
                                        Text(
                                          ' ago',
                                          style: greyColor9MediumTextStyle,
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                SizedBox(height: 3),
                                Row(
                                  children: [
                                    Text(
                                      'Payment Method: ',
                                      style: greyColor12MediumTextStyle,
                                    ),
                                    Text(
                                      item['paymentMethod'],
                                      style: darkBlueColor14SemiBoldTextStyle,
                                    ),
                                  ],
                                ),
                                SizedBox(height: 3),
                                Row(
                                  children: [
                                    Text(
                                      'Total Payment: ',
                                      style: greyColor12MediumTextStyle,
                                    ),
                                    Text(
                                      item['totalPayment'],
                                      style: darkBlueColor14SemiBoldTextStyle,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.fromLTRB(5.0, 5.0, 0.0, 0.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.location_on,
                                color: primaryColor,
                                size: 15,
                              ),
                              widthSpace,
                              widthSpace,
                              Text(
                                'Street: ',
                                style: darkBlueColor13SemiBoldTextStyle,
                              ),
                              Text(
                                item['toAddress'],
                                style: darkBlueColor13SemiBoldTextStyle,
                              ),
                            ],
                          ),
                          verticalDivider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(bottom: 5.0),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.navigation,
                                      color: primaryColor,
                                      size: 15,
                                    ),
                                    widthSpace,
                                    widthSpace,
                                    Text(
                                      'Street: ',
                                      style: darkBlueColor13SemiBoldTextStyle,
                                    ),
                                    Text(
                                      item['fromAddress'],
                                      style: darkBlueColor13SemiBoldTextStyle,
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 3.0),
                                decoration: BoxDecoration(
                                  color: primaryColor,
                                  borderRadius: BorderRadius.only(
                                    bottomRight: Radius.circular(10.0),
                                  ),
                                ),
                                child: Icon(
                                  Icons.arrow_forward,
                                  color: whiteColor,
                                  size: 20,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  activeDeliveriesList() {
    return Expanded(
      child: ListView.builder(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        itemCount: activeDeliveryList.length,
        itemBuilder: (context, index) {
          final item = activeDeliveryList[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(
              fixPadding * 2.0,
              index == 0 ? fixPadding * 2.0 : fixPadding,
              fixPadding * 2.0,
              fixPadding,
            ),
            child: InkWell(
              onTap: () => activeOrderDetails(),
              child: Container(
                decoration: BoxDecoration(
                  color: lightBlueColor,
                  borderRadius: BorderRadius.circular(10.0),
                  boxShadow: [
                    BoxShadow(
                      color: greyColor.withOpacity(0.1),
                      spreadRadius: 2.5,
                      blurRadius: 2.5,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(5.0),
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          topRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            height: 45.0,
                            width: 35.0,
                            color: whiteColor,
                            child: Image.asset(
                              'assets/icons/order_food.png',
                              color: darkBlueColor,
                            ),
                          ),
                          widthSpace,
                          widthSpace,
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Row(
                                      children: [
                                        Text(
                                          'Order ID: ',
                                          style: greyColor12MediumTextStyle,
                                        ),
                                        Text(
                                          item['orderId'],
                                          style:
                                              darkBlueColor14SemiBoldTextStyle,
                                        ),
                                      ],
                                    ),
                                    Container(
                                      height: 7.0,
                                      width: 7.0,
                                      decoration: BoxDecoration(
                                        color: Colors.green,
                                        shape: BoxShape.circle,
                                      ),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 3),
                                Row(
                                  children: [
                                    Text(
                                      'Payment Method: ',
                                      style: greyColor12MediumTextStyle,
                                    ),
                                    Text(
                                      item['paymentMethod'],
                                      style: darkBlueColor14SemiBoldTextStyle,
                                    ),
                                  ],
                                ),
                                SizedBox(height: 3),
                                Row(
                                  children: [
                                    Text(
                                      'Total Payment: ',
                                      style: greyColor12MediumTextStyle,
                                    ),
                                    Text(
                                      item['totalPayment'],
                                      style: darkBlueColor14SemiBoldTextStyle,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.fromLTRB(5.0, 5.0, 0.0, 0.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.location_on,
                                color: primaryColor,
                                size: 15,
                              ),
                              widthSpace,
                              widthSpace,
                              Text(
                                'Street: ',
                                style: darkBlueColor13SemiBoldTextStyle,
                              ),
                              Text(
                                item['toAddress'],
                                style: darkBlueColor13SemiBoldTextStyle,
                              ),
                            ],
                          ),
                          verticalDivider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(bottom: 5.0),
                                child: Row(
                                  children: [
                                    Icon(
                                      Icons.navigation,
                                      color: primaryColor,
                                      size: 15,
                                    ),
                                    widthSpace,
                                    widthSpace,
                                    Text(
                                      'Street: ',
                                      style: darkBlueColor13SemiBoldTextStyle,
                                    ),
                                    Text(
                                      item['fromAddress'],
                                      style: darkBlueColor13SemiBoldTextStyle,
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 3.0),
                                decoration: BoxDecoration(
                                  color: primaryColor,
                                  borderRadius: BorderRadius.only(
                                    bottomRight: Radius.circular(10.0),
                                  ),
                                ),
                                child: Icon(
                                  Icons.arrow_forward,
                                  color: whiteColor,
                                  size: 20,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  newOrderDetails() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          child: Wrap(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: bgColor,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(fixPadding),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: darkBlueColor,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          topRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Text(
                        'Order ID: ACR147852',
                        style: whiteColor13SemiBoldTextStyle,
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(fixPadding * 2.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Column(
                        children: [
                          detailsCard(
                            title: 'Order',
                            details: Column(
                              children: [
                                detailsRow(
                                  title: 'Deal 1',
                                  detail: '\$28.00',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: '7up Regular 250ml',
                                  detail: '\$2.50',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: 'Delivery Charge',
                                  detail: '\$1.50',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: 'Total',
                                  detail: '\$32.00',
                                  style: primaryColor14SemiBoldTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          detailsCard(
                            title: 'Location',
                            details: Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  fixPadding, 3.0, fixPadding, 8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.location_on,
                                        color: primaryColor,
                                        size: 15,
                                      ),
                                      widthSpace,
                                      widthSpace,
                                      Text(
                                        'Street: ',
                                        style: darkBlueColor14MediumTextStyle,
                                      ),
                                      Expanded(
                                        child: Text(
                                          '48, Hunters Road, Vepery',
                                          overflow: TextOverflow.ellipsis,
                                          style: darkBlueColor14MediumTextStyle,
                                        ),
                                      ),
                                    ],
                                  ),
                                  verticalDivider(),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.navigation,
                                        color: primaryColor,
                                        size: 15,
                                      ),
                                      widthSpace,
                                      widthSpace,
                                      Text(
                                        'Street: ',
                                        style: darkBlueColor14MediumTextStyle,
                                      ),
                                      Expanded(
                                        child: Text(
                                          'Great Western, Mcc Lane, Fort',
                                          overflow: TextOverflow.ellipsis,
                                          style: darkBlueColor14MediumTextStyle,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          detailsCard(
                            title: 'Customer',
                            details: Column(
                              children: [
                                detailsRow(
                                  title: 'Name',
                                  detail: 'Samantha John',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: 'Mobile Number',
                                  detail: '(+91) 1234567890',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          detailsCard(
                            title: 'Payment',
                            details: Column(
                              children: [
                                detailsRow(
                                  title: 'Payment Method',
                                  detail: 'Online',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: fixPadding * 3.0,
                            ),
                            child: Row(
                              children: [
                                Expanded(
                                  child: InkWell(
                                    onTap: () {
                                      Navigator.pop(context);
                                      rejectDialog();
                                    },
                                    child: Container(
                                      padding: EdgeInsets.all(fixPadding),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        border: Border.all(color: primaryColor),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      child: Text(
                                        'Reject',
                                        style: primaryColor15BoldTextStyle,
                                      ),
                                    ),
                                  ),
                                ),
                                widthSpace,
                                widthSpace,
                                widthSpace,
                                Expanded(
                                  child: InkWell(
                                    onTap: () {
                                      Navigator.pop(context);
                                      Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                DeliveryOrderLocation()),
                                      );
                                    },
                                    child: Container(
                                      padding: EdgeInsets.all(fixPadding),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: primaryColor,
                                        border: Border.all(color: primaryColor),
                                        borderRadius:
                                            BorderRadius.circular(10.0),
                                      ),
                                      child: Text(
                                        'Accept',
                                        style: whiteColor15BoldTextStyle,
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  activeOrderDetails() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          child: Wrap(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: bgColor,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(fixPadding),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: darkBlueColor,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          topRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Text(
                        'Order ID: ACR147852',
                        style: whiteColor13SemiBoldTextStyle,
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(fixPadding * 2.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Column(
                        children: [
                          detailsCard(
                            title: 'Order',
                            details: Column(
                              children: [
                                detailsRow(
                                  title: 'Deal 1',
                                  detail: '\$28.00',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: '7up Regular 250ml',
                                  detail: '\$2.50',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: 'Delivery Charge',
                                  detail: '\$1.50',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: 'Total',
                                  detail: '\$32.00',
                                  style: primaryColor14SemiBoldTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          detailsCard(
                            title: 'Location',
                            details: Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  fixPadding, 3.0, fixPadding, 8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.location_on,
                                        color: primaryColor,
                                        size: 15,
                                      ),
                                      widthSpace,
                                      widthSpace,
                                      Text(
                                        'Street: ',
                                        style: darkBlueColor14MediumTextStyle,
                                      ),
                                      Expanded(
                                        child: Text(
                                          '48, Hunters Road, Vepery',
                                          overflow: TextOverflow.ellipsis,
                                          style: darkBlueColor14MediumTextStyle,
                                        ),
                                      ),
                                    ],
                                  ),
                                  verticalDivider(),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.navigation,
                                        color: primaryColor,
                                        size: 15,
                                      ),
                                      widthSpace,
                                      widthSpace,
                                      Text(
                                        'Street: ',
                                        style: darkBlueColor14MediumTextStyle,
                                      ),
                                      Expanded(
                                        child: Text(
                                          'Great Western, Mcc Lane, Fort',
                                          overflow: TextOverflow.ellipsis,
                                          style: darkBlueColor14MediumTextStyle,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          detailsCard(
                            title: 'Customer',
                            details: Column(
                              children: [
                                detailsRow(
                                  title: 'Name',
                                  detail: 'Samantha John',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: 'Mobile Number',
                                  detail: '(+91) 1234567890',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          detailsCard(
                            title: 'Payment',
                            details: Column(
                              children: [
                                detailsRow(
                                  title: 'Payment Method',
                                  detail: 'Online',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          InkWell(
                            onTap: () {
                              Navigator.pop(context);
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => DeliveryOrderLocation(),
                                ),
                              );
                            },
                            child: Container(
                              padding: EdgeInsets.all(fixPadding),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: primaryColor,
                                border: Border.all(color: primaryColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Text(
                                'Start',
                                style: whiteColor15BoldTextStyle,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  detailsCard({String title, Widget details}) {
    return Container(
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [
          BoxShadow(
            color: greyColor.withOpacity(0.1),
            spreadRadius: 2.5,
            blurRadius: 2.5,
          ),
        ],
      ),
      child: Column(
        children: [
          heightSpace,
          Text(
            title,
            style: primaryColor14SemiBoldTextStyle,
          ),
          divider(),
          details,
        ],
      ),
    );
  }

  detailsRow({title, detail, TextStyle style}) {
    return Padding(
      padding: EdgeInsets.fromLTRB(fixPadding, 0.0, fixPadding, 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: style,
          ),
          Text(
            detail,
            style: style,
          ),
        ],
      ),
    );
  }

  rejectDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 5.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          backgroundColor: bgColor,
          child: Wrap(
            children: [
              Container(
                padding: EdgeInsets.all(fixPadding * 2.0),
                child: Column(
                  children: [
                    Text(
                      'Write a specific reson to reject order.',
                      style: darkBlueColor13SemiBoldTextStyle,
                    ),
                    heightSpace,
                    heightSpace,
                    TextField(
                      cursorColor: primaryColor,
                      style: darkBlueColor11SemiBoldTextStyle,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Write here...',
                        hintStyle: greyColor11RegularTextStyle,
                        border: UnderlineInputBorder(
                            borderSide: BorderSide(color: greyColor)),
                        focusedBorder: UnderlineInputBorder(
                            borderSide: BorderSide(color: greyColor)),
                      ),
                    ),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              padding: EdgeInsets.all(fixPadding),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                border: Border.all(color: primaryColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Text(
                                'Cancel',
                                style: primaryColor15BoldTextStyle,
                              ),
                            ),
                          ),
                        ),
                        widthSpace,
                        widthSpace,
                        widthSpace,
                        Expanded(
                          child: InkWell(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              padding: EdgeInsets.all(fixPadding),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: primaryColor,
                                border: Border.all(color: primaryColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Text(
                                'Send',
                                style: whiteColor15BoldTextStyle,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  divider() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: fixPadding / 2),
      color: darkBlueColor,
      height: 1.3,
      width: double.infinity,
    );
  }

  verticalDivider() {
    return Padding(
      padding: const EdgeInsets.only(left: 6.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 3.0,
            width: 3.0,
            decoration: BoxDecoration(
              color: darkBlueColor,
              shape: BoxShape.circle,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 1.5),
            height: 3.0,
            width: 3.0,
            decoration: BoxDecoration(
              color: darkBlueColor,
              shape: BoxShape.circle,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 1.5),
            height: 3.0,
            width: 3.0,
            decoration: BoxDecoration(
              color: darkBlueColor,
              shape: BoxShape.circle,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 1.5),
            height: 3.0,
            width: 3.0,
            decoration: BoxDecoration(
              color: darkBlueColor,
              shape: BoxShape.circle,
            ),
          ),
        ],
      ),
    );
  }
}
