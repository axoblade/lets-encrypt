import 'package:foodex_restaurant_app/pages/screen.dart';

class AddCategory extends StatefulWidget {
  @override
  _AddCategoryState createState() => _AddCategoryState();
}

class _AddCategoryState extends State<AddCategory> {
  double height;
  double width;
  String dropdownValue;
  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
        title: Text(
          'Add Category',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        children: [
          image(),
          nameTextField(),
          categoryTextField(),
          button(),
        ],
      ),
    );
  }

  image() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: fixPadding * 2.0,
        vertical: fixPadding,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Upload Category Image',
            style: darkBlueColor15SemiBoldTextStyle,
          ),
          heightSpace,
          heightSpace,
          Padding(
            padding: const EdgeInsets.only(left: fixPadding * 1.5),
            child: InkWell(
              onTap: () => changeItemImage(),
              child: Container(
                height: height * 0.09,
                width: width * 0.18,
                decoration: BoxDecoration(
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(5.0),
                  boxShadow: [
                    BoxShadow(
                      color: blackColor.withOpacity(0.1),
                      spreadRadius: 1.5,
                      blurRadius: 1.5,
                    ),
                  ],
                ),
                child: Icon(
                  Icons.add_a_photo_rounded,
                  color: darkBlueColor,
                  size: 20,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  changeItemImage() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          color: bgColor,
          child: Wrap(
            children: <Widget>[
              Container(
                padding: EdgeInsets.all(fixPadding),
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: fixPadding),
                      child: Text(
                        'Choose Option',
                        textAlign: TextAlign.center,
                        style: darkBlueColor14SemiBoldTextStyle,
                      ),
                    ),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        padding: EdgeInsets.all(10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              Icons.camera_alt,
                              color: darkBlueColor,
                              size: 18.0,
                            ),
                            widthSpace,
                            widthSpace,
                            Text(
                              'Camera',
                              style: darkBlueColor13SemiBoldTextStyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        padding: EdgeInsets.all(10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              Icons.photo_library,
                              color: darkBlueColor,
                              size: 18.0,
                            ),
                            widthSpace,
                            widthSpace,
                            Text(
                              'Select Photo From Gallery',
                              style: darkBlueColor13SemiBoldTextStyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        );
      },
    );
  }

  nameTextField() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        fixPadding * 1.5,
        fixPadding * 2.0,
        fixPadding * 2.0,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Enter Category Name',
            style: darkBlueColor15SemiBoldTextStyle,
          ),
          heightSpace,
          heightSpace,
          Container(
            height: 42,
            padding: EdgeInsets.symmetric(horizontal: fixPadding),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: TextField(
              cursorColor: primaryColor,
              style: greyColor13SemiBoldTextStyle,
              decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.zero,
                hintStyle: greyColor13RegularTextStyle,
                hintText: 'eg. Fast Food',
                border: UnderlineInputBorder(borderSide: BorderSide.none),
              ),
            ),
          ),
        ],
      ),
    );
  }

  categoryTextField() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        5.0,
        fixPadding * 2.0,
        fixPadding * 2.0,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Choose Parent Category',
            style: darkBlueColor15SemiBoldTextStyle,
          ),
          heightSpace,
          heightSpace,
          Container(
            height: 42,
            padding: EdgeInsets.symmetric(horizontal: fixPadding),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: DropdownButtonFormField(
              decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.zero,
                border: InputBorder.none,
              ),
              value: dropdownValue,
              style: greyColor13SemiBoldTextStyle,
              icon: Icon(
                Icons.keyboard_arrow_down,
                color: greyColor,
              ),
              hint: Text(
                'eg. Fast Food',
                style: greyColor13RegularTextStyle,
              ),
              onChanged: (String newValue) {
                setState(() {
                  dropdownValue = newValue;
                });
              },
              items: <String>[
                'Fast Food',
                'Starter',
                'Main Course',
                'Dessert',
              ].map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  button() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 7.0,
        fixPadding * 1.5,
        fixPadding * 7.0,
        fixPadding * 3.0,
      ),
      child: Row(
        children: [
          Expanded(
            child: InkWell(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: EdgeInsets.all(fixPadding),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  border: Border.all(color: primaryColor),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'Cancel',
                  style: primaryColor15BoldTextStyle,
                ),
              ),
            ),
          ),
          widthSpace,
          widthSpace,
          widthSpace,
          Expanded(
            child: InkWell(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: EdgeInsets.all(fixPadding),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: primaryColor,
                  border: Border.all(color: primaryColor),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'Save',
                  style: whiteColor15BoldTextStyle,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
