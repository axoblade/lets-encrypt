import 'package:foodex_deliveryboy_app/pages/screen.dart';

class Profile extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          'Profile',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        children: [
          userDetails(context),
          profileDetails(
            child: Column(
              children: [
                profileDetailsRow(
                  ontap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Notifications()),
                  ),
                  icon: 'assets/icons/notification.png',
                  title: 'Notifications',
                  color: darkBlueColor,
                ),
                profileDetailsRow(
                  ontap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => ShareAndEarn()),
                  ),
                  icon: 'assets/icons/share.png',
                  title: 'Share & Earn',
                  color: darkBlueColor,
                ),
                profileDetailsRow(
                  ontap: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => Settings()),
                  ),
                  icon: 'assets/icons/settings.png',
                  title: 'Settings',
                  color: darkBlueColor,
                ),
                profileDetailsRow(
                  ontap: () {},
                  icon: 'assets/icons/support.png',
                  title: 'Support',
                  color: darkBlueColor,
                ),
              ],
            ),
          ),
          profileDetails(
            child: profileDetailsRow(
              ontap: () => logoutDialog(context),
              icon: 'assets/icons/logout.png',
              title: 'Logout',
              color: primaryColor,
            ),
          ),
        ],
      ),
    );
  }

  userDetails(context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        fixPadding,
        fixPadding * 2.0,
        fixPadding * 2.0,
      ),
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => PersonalInformation()),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Hero(
                  tag: 'profilePick',
                  child: Container(
                    height: 60.0,
                    width: 60.0,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5),
                      image: DecorationImage(
                        image: AssetImage('assets/users/user1.png'),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                widthSpace,
                widthSpace,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Devin Shah',
                      style: darkBlueColor15SemiBoldTextStyle,
                    ),
                    Text(
                      '(+91) 1234567890',
                      style: greyColor13MediumTextStyle,
                    ),
                  ],
                ),
              ],
            ),
            IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.arrow_forward_ios,
                color: greyColor,
                size: 12,
              ),
            ),
          ],
        ),
      ),
    );
  }

  profileDetails({Widget child}) {
    return Container(
      margin: EdgeInsets.symmetric(
        horizontal: fixPadding * 2.0,
        vertical: fixPadding,
      ),
      padding: EdgeInsets.symmetric(
        horizontal: fixPadding,
        vertical: 5.0,
      ),
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: greyColor.withOpacity(0.1),
            spreadRadius: 2.5,
            blurRadius: 2.5,
          ),
        ],
      ),
      child: child,
    );
  }

  profileDetailsRow({Function ontap, String icon, String title, Color color}) {
    return InkWell(
      onTap: ontap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: fixPadding),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Image.asset(
                  icon,
                  height: 18,
                  width: 18,
                  color: color,
                ),
                widthSpace,
                widthSpace,
                widthSpace,
                Text(
                  title,
                  style: TextStyle(
                    color: color,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
            Icon(
              Icons.arrow_forward_ios,
              color: greyColor,
              size: 12,
            ),
          ],
        ),
      ),
    );
  }

  logoutDialog(context) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          backgroundColor: bgColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 5.0),
          child: Wrap(
            children: [
              Padding(
                padding: const EdgeInsets.all(fixPadding * 1.5),
                child: Column(
                  children: [
                    Text(
                      'Are you sure want to logout?',
                      style: darkBlueColor15SemiBoldTextStyle,
                    ),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              padding: EdgeInsets.all(fixPadding),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                border: Border.all(color: primaryColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Text(
                                'Cancel',
                                style: primaryColor15BoldTextStyle,
                              ),
                            ),
                          ),
                        ),
                        widthSpace,
                        widthSpace,
                        widthSpace,
                        widthSpace,
                        Expanded(
                          child: InkWell(
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(builder: (context) => SignIn()),
                            ),
                            child: Container(
                              padding: EdgeInsets.all(fixPadding),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: primaryColor,
                                border: Border.all(color: primaryColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Text(
                                'Logout',
                                style: whiteColor15BoldTextStyle,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        );
      },
    );
  }
}
