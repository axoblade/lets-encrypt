import 'dart:async';

import 'package:foodex_deliveryboy_app/pages/screen.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class DeliveryOrderLocation extends StatefulWidget {
  @override
  _DeliveryOrderLocationState createState() => _DeliveryOrderLocationState();
}

class _DeliveryOrderLocationState extends State<DeliveryOrderLocation> {
  double height;
  double width;
  GoogleMapController mapController;
  final Map<MarkerId, Marker> _markers = Map<MarkerId, Marker>();
  MarkerId id1 = MarkerId('Id1');
  MarkerId id2 = MarkerId('Id2');
  MarkerId id3 = MarkerId('Id3');
  final Set<Polyline> polyline = {};
  List<LatLng> latlngSegment1 = [];
  BitmapDescriptor customIcon1;
  BitmapDescriptor customIcon2;
  BitmapDescriptor customIcon3;

  @override
  void initState() {
    super.initState();
    getIcon1();
    getIcon2();
    getIcon3();
  }

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Stack(
        children: [
          googleMap(),
          backArrow(),
          orderDetailAndCallButton(),
          bottomCard(),
        ],
      ),
    );
  }

  getIcon1() async {
    var customIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(size: Size(5, 5)), 'assets/marker1.png');
    setState(() {
      customIcon1 = customIcon;
    });
  }

  getIcon2() async {
    var customIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(size: Size(5, 5)), 'assets/marker2.png');
    setState(() {
      customIcon2 = customIcon;
    });
  }

  getIcon3() async {
    var customIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(size: Size(5, 5)), 'assets/marker3.png');
    setState(() {
      customIcon3 = customIcon;
    });
  }

  googleMap() {
    return Container(
      height: height,
      width: width,
      child: GoogleMap(
        markers: Set<Marker>.of(_markers.values),
        polylines: polyline,
        initialCameraPosition: CameraPosition(
          target: LatLng(18.495351, -69.949366),
          zoom: 14,
        ),
        onMapCreated: (GoogleMapController controller) {
          mapController = controller;
          setState(() {
            latlngSegment1.add(LatLng(18.495351, -69.949366));
            latlngSegment1.add(LatLng(18.489338, -69.947091));
            latlngSegment1.add(LatLng(18.488213, -69.959186));
            Marker marker1 = Marker(
              icon: customIcon3,
              markerId: id1,
              position: LatLng(18.488213, -69.959186),
            );
            _markers[id1] = marker1;
            Marker marker2 = Marker(
              icon: customIcon1,
              markerId: id2,
              position: LatLng(18.489338, -69.947091),
            );
            _markers[id2] = marker2;
            Marker marker3 = Marker(
              icon: customIcon2,
              markerId: id3,
              position: LatLng(18.495351, -69.949366),
            );
            _markers[id3] = marker3;
            polyline.add(
              Polyline(
                polylineId: PolylineId('polyLine'),
                points: latlngSegment1,
                width: 3,
                color: darkBlueColor,
              ),
            );
          });
        },
      ),
    );
  }

  backArrow() {
    return Positioned(
      top: 80.0,
      left: 20.0,
      child: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: Icon(
          Icons.arrow_back_ios,
          color: blackColor,
        ),
      ),
    );
  }

  orderDetailAndCallButton() {
    return Positioned(
      bottom: 180.0,
      right: 20.0,
      child: Column(
        children: [
          InkWell(
            onTap: () => orderDetails(context),
            child: Container(
              padding: EdgeInsets.all(fixPadding),
              decoration: BoxDecoration(
                color: whiteColor,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: greyColor.withOpacity(0.1),
                    spreadRadius: 2.5,
                    blurRadius: 2.5,
                  ),
                ],
              ),
              child: Image.asset(
                'assets/icons/order_detail.png',
                height: 20,
                width: 20,
              ),
            ),
          ),
          heightSpace,
          heightSpace,
          Container(
            padding: EdgeInsets.all(fixPadding),
            decoration: BoxDecoration(
              color: whiteColor,
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Icon(
              Icons.call,
              color: darkBlueColor,
              size: 20,
            ),
          ),
        ],
      ),
    );
  }

  bottomCard() {
    return Positioned(
      bottom: 0.0,
      left: 0.0,
      right: 0.0,
      child: Container(
        padding: EdgeInsets.all(fixPadding),
        color: bgColor,
        child: Column(
          children: [
            Row(
              children: [
                Container(
                  height: 60.0,
                  width: 60.0,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    image: DecorationImage(
                      image: AssetImage('assets/users/user2.png'),
                      fit: BoxFit.cover,
                    ),
                  ),
                ),
                widthSpace,
                widthSpace,
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Aaron Doe',
                      style: darkBlueColor14SemiBoldTextStyle,
                    ),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    Row(
                      children: [
                        Icon(
                          Icons.location_on,
                          color: primaryColor,
                          size: 15,
                        ),
                        widthSpace,
                        widthSpace,
                        Text(
                          'Street: ',
                          style: darkBlueColor13MediumTextStyle,
                        ),
                        Text(
                          '48, Hunters Road, Vepery',
                          overflow: TextOverflow.ellipsis,
                          style: darkBlueColor13MediumTextStyle,
                        ),
                      ],
                    ),
                    verticalDivider(),
                    Row(
                      children: [
                        Icon(
                          Icons.navigation,
                          color: primaryColor,
                          size: 15,
                        ),
                        widthSpace,
                        widthSpace,
                        Text(
                          'Street: ',
                          style: darkBlueColor13MediumTextStyle,
                        ),
                        Text(
                          'Great Western, Mcc Lane, Fort',
                          overflow: TextOverflow.ellipsis,
                          style: darkBlueColor13MediumTextStyle,
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            heightSpace,
            heightSpace,
            heightSpace,
            Padding(
              padding: EdgeInsets.symmetric(horizontal: fixPadding * 12.0),
              child: InkWell(
                onTap: () => finishDialog(context),
                child: Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: fixPadding * 3.0,
                    vertical: fixPadding,
                  ),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: primaryColor,
                    border: Border.all(color: primaryColor),
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Text(
                    'Finish',
                    style: whiteColor15BoldTextStyle,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  finishDialog(context) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 5.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          backgroundColor: bgColor,
          child: Wrap(
            children: [
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: fixPadding * 2.0,
                  vertical: fixPadding,
                ),
                child: Column(
                  children: [
                    Image.asset(
                      'assets/icons/finish.png',
                      color: primaryColor,
                      height: 50.0,
                      width: 50.0,
                    ),
                    heightSpace,
                    heightSpace,
                    Text(
                      'Congratulation Order completed.',
                      textAlign: TextAlign.center,
                      style: darkBlueColor12RegularTextStyle,
                    ),
                    heightSpace,
                    Text(
                      'You have completed order number ACR147852',
                      textAlign: TextAlign.center,
                      style: darkBlueColor13SemiBoldTextStyle,
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
    Timer(Duration(seconds: 5), () {
      currentIndex = 0;
      Navigator.push(
        context,
        MaterialPageRoute(builder: (context) => BottomBar()),
      );
    });
  }

  orderDetails(context) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          child: Wrap(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: bgColor,
                  borderRadius: BorderRadius.circular(10.0),
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(fixPadding),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: darkBlueColor,
                        borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10.0),
                          topRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Text(
                        'Order ID: ACR147852',
                        style: whiteColor13SemiBoldTextStyle,
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.all(fixPadding * 2.0),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.only(
                          bottomLeft: Radius.circular(10.0),
                          bottomRight: Radius.circular(10.0),
                        ),
                      ),
                      child: Column(
                        children: [
                          detailsCard(
                            title: 'Order',
                            details: Column(
                              children: [
                                detailsRow(
                                  title: 'Deal 1',
                                  detail: '\$28.00',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: '7up Regular 250ml',
                                  detail: '\$2.50',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: 'Delivery Charge',
                                  detail: '\$1.50',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: 'Total',
                                  detail: '\$32.00',
                                  style: primaryColor14SemiBoldTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          detailsCard(
                            title: 'Location',
                            details: Padding(
                              padding: const EdgeInsets.fromLTRB(
                                  fixPadding, 3.0, fixPadding, 8.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.location_on,
                                        color: primaryColor,
                                        size: 15,
                                      ),
                                      widthSpace,
                                      widthSpace,
                                      Text(
                                        'Street: ',
                                        style: darkBlueColor14MediumTextStyle,
                                      ),
                                      Expanded(
                                        child: Text(
                                          '48, Hunters Road, Vepery',
                                          overflow: TextOverflow.ellipsis,
                                          style: darkBlueColor14MediumTextStyle,
                                        ),
                                      ),
                                    ],
                                  ),
                                  verticalDivider(),
                                  Row(
                                    children: [
                                      Icon(
                                        Icons.navigation,
                                        color: primaryColor,
                                        size: 15,
                                      ),
                                      widthSpace,
                                      widthSpace,
                                      Text(
                                        'Street: ',
                                        style: darkBlueColor14MediumTextStyle,
                                      ),
                                      Expanded(
                                        child: Text(
                                          'Great Western, Mcc Lane, Fort',
                                          overflow: TextOverflow.ellipsis,
                                          style: darkBlueColor14MediumTextStyle,
                                        ),
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          detailsCard(
                            title: 'Customer',
                            details: Column(
                              children: [
                                detailsRow(
                                  title: 'Name',
                                  detail: 'Samantha John',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                                detailsRow(
                                  title: 'Mobile Number',
                                  detail: '(+91) 1234567890',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          detailsCard(
                            title: 'Payment',
                            details: Column(
                              children: [
                                detailsRow(
                                  title: 'Payment Method',
                                  detail: 'Online',
                                  style: darkBlueColor14MediumTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          heightSpace,
                          InkWell(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              padding: EdgeInsets.all(fixPadding),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: primaryColor,
                                border: Border.all(color: primaryColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Text(
                                'Ok',
                                style: whiteColor15BoldTextStyle,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  detailsCard({String title, Widget details}) {
    return Container(
      decoration: BoxDecoration(
        color: whiteColor,
        boxShadow: [
          BoxShadow(
            color: greyColor.withOpacity(0.1),
            spreadRadius: 2.5,
            blurRadius: 2.5,
          ),
        ],
      ),
      child: Column(
        children: [
          heightSpace,
          Text(
            title,
            style: primaryColor14SemiBoldTextStyle,
          ),
          divider(),
          details,
        ],
      ),
    );
  }

  detailsRow({title, detail, TextStyle style}) {
    return Padding(
      padding: EdgeInsets.fromLTRB(fixPadding, 0.0, fixPadding, 8.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: style,
          ),
          Text(
            detail,
            style: style,
          ),
        ],
      ),
    );
  }

  divider() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: fixPadding / 2),
      color: darkBlueColor,
      height: 1.3,
      width: double.infinity,
    );
  }

  verticalDivider() {
    return Padding(
      padding: const EdgeInsets.only(left: 6.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            height: 3.0,
            width: 3.0,
            decoration: BoxDecoration(
              color: darkBlueColor,
              shape: BoxShape.circle,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 1.5),
            height: 3.0,
            width: 3.0,
            decoration: BoxDecoration(
              color: darkBlueColor,
              shape: BoxShape.circle,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 1.5),
            height: 3.0,
            width: 3.0,
            decoration: BoxDecoration(
              color: darkBlueColor,
              shape: BoxShape.circle,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 1.5),
            height: 3.0,
            width: 3.0,
            decoration: BoxDecoration(
              color: darkBlueColor,
              shape: BoxShape.circle,
            ),
          ),
        ],
      ),
    );
  }
}
