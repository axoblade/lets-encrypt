import 'package:foodex_user_app/pages/screen.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class TrackOrder extends StatefulWidget {
  @override
  _TrackOrderState createState() => _TrackOrderState();
}

class _TrackOrderState extends State<TrackOrder> {
  GoogleMapController mapController;
  final Map<MarkerId, Marker> _markers = Map<MarkerId, Marker>();
  MarkerId id1 = MarkerId('Id1');
  MarkerId id2 = MarkerId('Id2');
  MarkerId id3 = MarkerId('Id3');
  final Set<Polyline> polyline = {};
  List<LatLng> latlngSegment1 = [];
  BitmapDescriptor customIcon1;
  BitmapDescriptor customIcon2;
  BitmapDescriptor customIcon3;

  @override
  void initState() {
    super.initState();
    getIcon1();
    getIcon2();
    getIcon3();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          googleMap(),
          backArrow(),
          bottomCard(),
        ],
      ),
    );
  }

  getIcon1() async {
    var customIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(size: Size(5, 5)), 'assets/marker1.png');
    setState(() {
      customIcon1 = customIcon;
    });
  }

  getIcon2() async {
    var customIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(size: Size(5, 5)), 'assets/marker2.png');
    setState(() {
      customIcon2 = customIcon;
    });
  }

  getIcon3() async {
    var customIcon = await BitmapDescriptor.fromAssetImage(
        ImageConfiguration(size: Size(5, 5)), 'assets/marker3.png');
    setState(() {
      customIcon3 = customIcon;
    });
  }

  googleMap() {
    return Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: GoogleMap(
        markers: Set<Marker>.of(_markers.values),
        polylines: polyline,
        initialCameraPosition: CameraPosition(
          target: LatLng(18.495351, -69.949366),
          zoom: 14,
        ),
        onMapCreated: (GoogleMapController controller) {
          mapController = controller;
          setState(() {
            latlngSegment1.add(LatLng(18.495351, -69.949366));
            latlngSegment1.add(LatLng(18.489338, -69.947091));
            latlngSegment1.add(LatLng(18.488213, -69.959186));
            Marker marker1 = Marker(
              icon: customIcon3,
              markerId: id1,
              position: LatLng(18.488213, -69.959186),
            );
            _markers[id1] = marker1;
            Marker marker2 = Marker(
              icon: customIcon1,
              markerId: id2,
              position: LatLng(18.489338, -69.947091),
            );
            _markers[id2] = marker2;
            Marker marker3 = Marker(
              icon: customIcon2,
              markerId: id3,
              position: LatLng(18.495351, -69.949366),
            );
            _markers[id3] = marker3;
            polyline.add(
              Polyline(
                polylineId: PolylineId('polyLine'),
                points: latlngSegment1,
                width: 3,
                color: darkBlueColor,
              ),
            );
          });
        },
      ),
    );
  }

  backArrow() {
    return Positioned(
      top: 70.0,
      left: 20.0,
      child: IconButton(
        onPressed: () => Navigator.pop(context),
        icon: Icon(Icons.arrow_back_ios),
      ),
    );
  }

  bottomCard() {
    return Positioned(
      bottom: 0.0,
      right: 20.0,
      left: 20.0,
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: fixPadding,
          vertical: fixPadding * 1.5,
        ),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(10),
            topRight: Radius.circular(10),
          ),
        ),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'Delivery man',
                  style: greyColor13RegularTextStyle,
                ),
                Text(
                  'Arriving in',
                  style: greyColor13RegularTextStyle,
                ),
              ],
            ),
            SizedBox(height: 3),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'George Anderson',
                  style: darkBlueColor15SemiBoldTextStyle,
                ),
                Text(
                  '10 mins',
                  style: darkBlueColor15SemiBoldTextStyle,
                ),
              ],
            ),
            heightSpace,
            heightSpace,
            heightSpace,
            heightSpace,
            Row(
              children: [
                widthSpace,
                widthSpace,
                Expanded(
                  child: Container(
                    padding: EdgeInsets.all(8.0),
                    alignment: Alignment.center,
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(color: primaryColor),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.call,
                          color: primaryColor,
                          size: 20,
                        ),
                        widthSpace,
                        Text(
                          'Call Now',
                          style: primaryColor15BoldTextStyle,
                        ),
                      ],
                    ),
                  ),
                ),
                widthSpace,
                widthSpace,
                widthSpace,
                widthSpace,
                Expanded(
                  child: InkWell(
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(builder: (context) => ChatScreen()),
                    ),
                    child: Container(
                      padding: EdgeInsets.all(8.0),
                      alignment: Alignment.center,
                      decoration: BoxDecoration(
                        color: primaryColor,
                        border: Border.all(color: primaryColor),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.messenger_sharp,
                            color: whiteColor,
                            size: 20,
                          ),
                          widthSpace,
                          Text(
                            'Message',
                            style: whiteColor15BoldTextStyle,
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                widthSpace,
                widthSpace,
              ],
            ),
          ],
        ),
      ),
    );
  }
}
