import 'package:foodex_deliveryboy_app/pages/screen.dart';
import 'package:foodex_deliveryboy_app/widget/column_builder.dart';

class History extends StatelessWidget {
  final todayHistoryList = [
    {
      'orderId': 'ACR147856',
      'paymentMethod': 'Online',
      'totalPayment': '\$32.00',
      'orderStatus': 'Delivered',
    },
    {
      'orderId': ' AWQ145698',
      'paymentMethod': 'Cash on delivery',
      'totalPayment': '\$35.00',
      'orderStatus': 'Delivered',
    },
    {
      'orderId': ' TRE123654',
      'paymentMethod': 'Online',
      'totalPayment': '\$40.00',
      'orderStatus': 'Pending',
    },
  ];

  final yesterdayHistoryList = [
    {
      'orderId': 'ACR147856',
      'paymentMethod': 'Online',
      'totalPayment': '\$32.00',
      'orderStatus': 'Rejected',
    },
    {
      'orderId': ' AWQ145698',
      'paymentMethod': 'Cash on delivery',
      'totalPayment': '\$35.00',
      'orderStatus': 'Delivered',
    },
    {
      'orderId': ' TRE123654',
      'paymentMethod': 'Online',
      'totalPayment': '\$40.00',
      'orderStatus': 'Delivered',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          'History',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        children: [
          title('Today'),
          todayHistory(),
          title('Yesterday'),
          yesterdayHistory(),
        ],
      ),
    );
  }

  title(String title) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: fixPadding * 2.0,
        vertical: fixPadding,
      ),
      color: lightBlueColor,
      child: Text(
        title,
        style: darkBlueColor15SemiBoldTextStyle,
      ),
    );
  }

  todayHistory() {
    return ColumnBuilder(
      itemCount: todayHistoryList.length,
      itemBuilder: (context, index) {
        final item = todayHistoryList[index];
        return Padding(
          padding: EdgeInsets.fromLTRB(
            fixPadding * 2.0,
            index == 0 ? fixPadding * 2.0 : 0.0,
            fixPadding * 2.0,
            fixPadding * 2.0,
          ),
          child: Container(
            decoration: BoxDecoration(
              color: lightBlueColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10.0),
                      topRight: Radius.circular(10.0),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        height: 45.0,
                        width: 35.0,
                        color: whiteColor,
                        child: Image.asset(
                          'assets/icons/order_food.png',
                          color: darkBlueColor,
                        ),
                      ),
                      widthSpace,
                      widthSpace,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                'Order ID: ',
                                style: greyColor12MediumTextStyle,
                              ),
                              Text(
                                item['orderId'],
                                style: darkBlueColor14SemiBoldTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 3),
                          Row(
                            children: [
                              Text(
                                'Payment Method: ',
                                style: greyColor12MediumTextStyle,
                              ),
                              Text(
                                item['paymentMethod'],
                                style: darkBlueColor14SemiBoldTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 3),
                          Row(
                            children: [
                              Text(
                                'Total Payment: ',
                                style: greyColor12MediumTextStyle,
                              ),
                              Text(
                                item['totalPayment'],
                                style: darkBlueColor14SemiBoldTextStyle,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 5.0, vertical: 7.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10.0),
                      bottomRight: Radius.circular(10.0),
                    ),
                  ),
                  child: Row(
                    children: [
                      Text(
                        'Order Status: ',
                        style: darkBlueColor13SemiBoldTextStyle,
                      ),
                      Text(
                        item['orderStatus'],
                        style: primaryColor13SemiBoldTextStyle,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  yesterdayHistory() {
    return ColumnBuilder(
      itemCount: yesterdayHistoryList.length,
      itemBuilder: (context, index) {
        final item = yesterdayHistoryList[index];
        return Padding(
          padding: EdgeInsets.fromLTRB(
            fixPadding * 2.0,
            index == 0 ? fixPadding * 2.0 : 0.0,
            fixPadding * 2.0,
            fixPadding * 2.0,
          ),
          child: Container(
            decoration: BoxDecoration(
              color: lightBlueColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(5.0),
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10.0),
                      topRight: Radius.circular(10.0),
                    ),
                  ),
                  child: Row(
                    children: [
                      Container(
                        height: 45.0,
                        width: 35.0,
                        color: whiteColor,
                        child: Image.asset(
                          'assets/icons/order_food.png',
                          color: darkBlueColor,
                        ),
                      ),
                      widthSpace,
                      widthSpace,
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Text(
                                'Order ID: ',
                                style: greyColor12MediumTextStyle,
                              ),
                              Text(
                                item['orderId'],
                                style: darkBlueColor14SemiBoldTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 3),
                          Row(
                            children: [
                              Text(
                                'Payment Method: ',
                                style: greyColor12MediumTextStyle,
                              ),
                              Text(
                                item['paymentMethod'],
                                style: darkBlueColor14SemiBoldTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 3),
                          Row(
                            children: [
                              Text(
                                'Total Payment: ',
                                style: greyColor12MediumTextStyle,
                              ),
                              Text(
                                item['totalPayment'],
                                style: darkBlueColor14SemiBoldTextStyle,
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                Container(
                  padding: EdgeInsets.symmetric(horizontal: 5.0, vertical: 7.0),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(10.0),
                      bottomRight: Radius.circular(10.0),
                    ),
                  ),
                  child: Row(
                    children: [
                      Text(
                        'Order Status: ',
                        style: darkBlueColor13SemiBoldTextStyle,
                      ),
                      Text(
                        item['orderStatus'],
                        style: primaryColor13SemiBoldTextStyle,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
