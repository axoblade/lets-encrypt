import 'package:foodex_restaurant_app/pages/screen.dart';
import 'package:foodex_restaurant_app/widget/column_builder.dart';

class SetDeliveryAreas extends StatefulWidget {
  @override
  _SetDeliveryAreasState createState() => _SetDeliveryAreasState();
}

class _SetDeliveryAreasState extends State<SetDeliveryAreas> {
  String dropdownValue1;
  String dropdownValue2;
  double width;

  final deliveryAreaList = [
    {
      'area': '2983 Heavner Court',
      'isSelected': true,
    },
    {
      'area': '2373 Sunset Drive',
      'isSelected': true,
    },
    {
      'area': '1098 Clarksburg Park Road',
      'isSelected': false,
    },
    {
      'area': '536 Mandan Road',
      'isSelected': true,
    },
    {
      'area': '4607 Abia Martin Drive',
      'isSelected': true,
    },
  ];

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
        title: Text(
          'Set Delivery Area\'s',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        children: [
          addNewArea(),
          deliveryAreasList(),
        ],
      ),
      bottomNavigationBar: saveButton(context),
    );
  }

  addNewArea() {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.only(top: fixPadding, bottom: fixPadding * 4.0),
          padding: EdgeInsets.symmetric(
            horizontal: fixPadding * 2.0,
            vertical: fixPadding,
          ),
          color: lightBlueColor,
          child: Row(
            children: [
              Text(
                'Add New Area',
                style: darkBlueColor14SemiBoldTextStyle,
              ),
            ],
          ),
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: width * 0.38,
              padding: EdgeInsets.symmetric(vertical: 5.0),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(
                  color: primaryColor,
                  width: 1.5,
                ),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton(
                  elevation: 0,
                  isDense: true,
                  hint: Text(
                    'Choose State',
                    style: primaryColor13SemiBoldTextStyle,
                  ),
                  icon: Icon(
                    Icons.keyboard_arrow_down,
                    color: primaryColor,
                    size: 20,
                  ),
                  value: dropdownValue1,
                  onChanged: (String newValue) {
                    setState(() {
                      dropdownValue1 = newValue;
                    });
                  },
                  style: primaryColor13SemiBoldTextStyle,
                  items: <String>[
                    'Gujarat',
                    'Maharashtra',
                    'Rajasthan',
                    'Delhi',
                    'Kerala',
                  ].map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                ),
              ),
            ),
            widthSpace,
            widthSpace,
            Container(
              width: width * 0.38,
              padding: EdgeInsets.symmetric(vertical: 5.0),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(
                  color: primaryColor,
                  width: 1.5,
                ),
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: DropdownButtonHideUnderline(
                child: DropdownButton(
                  elevation: 0,
                  isDense: true,
                  hint: Text(
                    'Choose City',
                    style: primaryColor13SemiBoldTextStyle,
                  ),
                  icon: Icon(
                    Icons.keyboard_arrow_down,
                    color: primaryColor,
                    size: 20,
                  ),
                  value: dropdownValue2,
                  onChanged: (String newValue) {
                    setState(() {
                      dropdownValue2 = newValue;
                    });
                  },
                  style: primaryColor13SemiBoldTextStyle,
                  items: <String>[
                    'Surat',
                    'Mumbai',
                    'Pune',
                    'Jaipur',
                    'Agra',
                  ].map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                ),
              ),
            ),
          ],
        ),
        Padding(
          padding: const EdgeInsets.symmetric(
            horizontal: fixPadding * 2.0,
            vertical: fixPadding * 2.0,
          ),
          child: TextField(
            cursorColor: primaryColor,
            style: darkBlueColor11SemiBoldTextStyle,
            decoration: InputDecoration(
              isDense: true,
              hintStyle: greyColor11RegularTextStyle,
              hintText: 'Enter area here...',
              border: UnderlineInputBorder(
                borderSide: BorderSide(color: greyColor),
              ),
              focusedBorder: UnderlineInputBorder(
                borderSide: BorderSide(color: greyColor),
              ),
            ),
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Container(
                padding: EdgeInsets.symmetric(
                  horizontal: fixPadding * 1.8,
                  vertical: 8.0,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(11.0),
                  color: darkBlueColor,
                ),
                child: Text(
                  'Add Area',
                  style: whiteColor11SemiBoldTextStyle,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  deliveryAreasList() {
    return Column(
      children: [
        Container(
          margin: EdgeInsets.only(
            top: fixPadding * 3.0,
            bottom: fixPadding * 2.0,
          ),
          padding: EdgeInsets.symmetric(
            horizontal: fixPadding * 2.0,
            vertical: fixPadding,
          ),
          color: lightBlueColor,
          child: Row(
            children: [
              Text(
                'Delivery Area List',
                style: darkBlueColor14SemiBoldTextStyle,
              ),
            ],
          ),
        ),
        ColumnBuilder(
          itemCount: deliveryAreaList.length,
          itemBuilder: (context, index) {
            final item = deliveryAreaList[index];
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
              child: Column(
                children: [
                  InkWell(
                    onTap: () {
                      setState(() {
                        item['isSelected'] = !item['isSelected'];
                      });
                    },
                    child: Row(
                      children: [
                        Container(
                          height: 20.0,
                          width: 20.0,
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: item['isSelected']
                                ? primaryColor
                                : Colors.transparent,
                            border: Border.all(color: primaryColor),
                            borderRadius: BorderRadius.circular(2.0),
                          ),
                          child: item['isSelected']
                              ? Icon(
                                  Icons.done,
                                  color: whiteColor,
                                  size: 12,
                                )
                              : Container(),
                        ),
                        widthSpace,
                        widthSpace,
                        widthSpace,
                        widthSpace,
                        Text(
                          item['area'],
                          style: darkBlueColor13MediumTextStyle,
                        ),
                      ],
                    ),
                  ),
                  divider(),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  divider() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: fixPadding * 1.5),
      color: greyColor,
      height: 1.0,
      width: double.infinity,
    );
  }

  saveButton(context) {
    return Padding(
      padding: EdgeInsets.all(fixPadding * 2.0),
      child: InkWell(
        borderRadius: BorderRadius.circular(10.0),
        onTap: () => Navigator.pop(context),
        child: Container(
          height: 50,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: primaryColor,
            borderRadius: BorderRadius.circular(10.0),
            boxShadow: [
              BoxShadow(
                color: primaryColor.withOpacity(0.2),
                spreadRadius: 2.5,
                blurRadius: 2.5,
              ),
            ],
          ),
          child: Text(
            'Save',
            style: whiteColor20BoldTextStyle,
          ),
        ),
      ),
    );
  }
}
