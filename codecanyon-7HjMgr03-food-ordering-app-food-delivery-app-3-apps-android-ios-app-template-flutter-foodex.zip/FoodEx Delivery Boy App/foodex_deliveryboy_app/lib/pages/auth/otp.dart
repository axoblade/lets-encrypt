import 'dart:async';

import 'package:foodex_deliveryboy_app/pages/screen.dart';

class Otp extends StatefulWidget {
  @override
  _OtpState createState() => _OtpState();
}

class _OtpState extends State<Otp> {
  TextEditingController controller1;
  TextEditingController controller2;
  TextEditingController controller3;
  TextEditingController controller4;

  FocusNode firstFocusNode = FocusNode();
  FocusNode secondFocusNode = FocusNode();
  FocusNode thirdFocusNode = FocusNode();
  FocusNode fourthFocusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    controller1 = TextEditingController();
    controller2 = TextEditingController();
    controller3 = TextEditingController();
    controller4 = TextEditingController();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
      ),
      body: Stack(
        children: [
          cornerImage(),
          ListView(
            children: [
              Container(
                padding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
                alignment: Alignment.center,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    heightSpace,
                    heightSpace,
                    Text(
                      'Verify Your Mobile',
                      textAlign: TextAlign.center,
                      style: darkBlueColor22BoldTextStyle,
                    ),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    Text(
                      'Enter your code here',
                      textAlign: TextAlign.center,
                      style: greyColor16MediumTextStyle,
                    ),
                    heightSpace,
                    Text(
                      'Please check your messages and\nenter the verification code we just sent you\n(+91) 1234567890',
                      textAlign: TextAlign.center,
                      style: greyColor11RegularTextStyle,
                    ),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    codeTextField(),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    verifyButton(),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  codeTextField() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Container(
          height: 55.0,
          width: 55.0,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(color: primaryColor.withOpacity(0.5)),
            color: primaryColor.withOpacity(0.4),
          ),
          child: TextField(
            focusNode: firstFocusNode,
            onChanged: (v) {
              String value = controller1.text ?? "";
              if (value.isEmpty) {
                return;
              }
              FocusScope.of(context).requestFocus(secondFocusNode);
            },
            controller: controller1,
            cursorColor: primaryColor,
            keyboardType: TextInputType.number,
            style: darkBlueColor18SemiBoldTextStyle,
            textAlign: TextAlign.center,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.zero,
              border: OutlineInputBorder(borderSide: BorderSide.none),
            ),
          ),
        ),
        Container(
          height: 55.0,
          width: 55.0,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(color: primaryColor.withOpacity(0.5)),
            color: primaryColor.withOpacity(0.4),
          ),
          child: TextField(
            focusNode: secondFocusNode,
            onChanged: (v) {
              String value = controller2.text ?? "";
              if (value.isEmpty) {
                FocusScope.of(context).requestFocus(firstFocusNode);
                return;
              }
              FocusScope.of(context).requestFocus(thirdFocusNode);
            },
            controller: controller2,
            cursorColor: primaryColor,
            keyboardType: TextInputType.number,
            style: darkBlueColor18SemiBoldTextStyle,
            textAlign: TextAlign.center,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.zero,
              border: OutlineInputBorder(borderSide: BorderSide.none),
            ),
          ),
        ),
        Container(
          height: 55.0,
          width: 55.0,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(color: primaryColor.withOpacity(0.5)),
            color: primaryColor.withOpacity(0.4),
          ),
          child: TextField(
            focusNode: thirdFocusNode,
            onChanged: (v) {
              String value = controller3.text ?? "";
              if (value.isEmpty) {
                FocusScope.of(context).requestFocus(secondFocusNode);
                return;
              }
              FocusScope.of(context).requestFocus(fourthFocusNode);
            },
            controller: controller3,
            cursorColor: primaryColor,
            keyboardType: TextInputType.number,
            style: darkBlueColor18SemiBoldTextStyle,
            textAlign: TextAlign.center,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.zero,
              border: OutlineInputBorder(borderSide: BorderSide.none),
            ),
          ),
        ),
        Container(
          height: 55.0,
          width: 55.0,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(10.0),
            border: Border.all(color: primaryColor.withOpacity(0.5)),
            color: primaryColor.withOpacity(0.4),
          ),
          child: TextField(
            focusNode: fourthFocusNode,
            onChanged: (v) {
              String value = controller4.text ?? "";
              if (value.isEmpty) {
                FocusScope.of(context).requestFocus(thirdFocusNode);
                return;
              }
              waitDialog();
            },
            controller: controller4,
            cursorColor: primaryColor,
            keyboardType: TextInputType.number,
            style: darkBlueColor18SemiBoldTextStyle,
            textAlign: TextAlign.center,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.zero,
              border: OutlineInputBorder(borderSide: BorderSide.none),
            ),
          ),
        ),
      ],
    );
  }

  waitDialog() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (contxet) {
        return Dialog(
          child: Wrap(
            alignment: WrapAlignment.center,
            children: [
              Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  CircularProgressIndicator(
                    color: primaryColor,
                  ),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  Text(
                    'Please Wait...',
                    style: greyColor16RegularTextStyle,
                  ),
                  heightSpace,
                  heightSpace,
                  heightSpace,
                  heightSpace,
                ],
              ),
            ],
          ),
        );
      },
    );
    Timer(
      Duration(seconds: 3),
      () {
        currentIndex = 0;
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => BottomBar()),
        );
      },
    );
  }

  verifyButton() {
    return InkWell(
      borderRadius: BorderRadius.circular(10.0),
      onTap: () => waitDialog(),
      child: Container(
        height: 50,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: primaryColor,
          borderRadius: BorderRadius.circular(10.0),
          boxShadow: [
            BoxShadow(
              color: primaryColor.withOpacity(0.2),
              spreadRadius: 2.5,
              blurRadius: 2.5,
            ),
          ],
        ),
        child: Text(
          'Verify Now',
          style: whiteColor20BoldTextStyle,
        ),
      ),
    );
  }

  cornerImage() {
    return Positioned(
      bottom: 0.0,
      left: 0.0,
      child: Image.asset(
        'assets/bg1.png',
        height: 170.0,
        width: 170.0,
        fit: BoxFit.cover,
      ),
    );
  }
}
