import 'package:foodex_restaurant_app/pages/screen.dart';

class DailyOffers extends StatefulWidget {
  @override
  _DailyOffersState createState() => _DailyOffersState();
}

class _DailyOffersState extends State<DailyOffers> {
  final dailyOfferList = [
    {
      'image': 'assets/daily_offers/offer1.png',
      'name': 'South Indian Thali - Veg',
      'description':
          '2 Vegetables, Rasam, Sambhar,4,Pooris, Rice, Aplam, Pickle, Curd & Dessert',
      'price': '\$29.60',
      'offerPrice': '\$26.00',
      'status': true,
    },
    {
      'image': 'assets/daily_offers/offer2.png',
      'name': 'Cheese Naan With Gravy',
      'description': 'Gravy, 2 Naan, Pickle, Raita, Salad &  Papad',
      'price': '\$25.60',
      'offerPrice': '\$23.60',
      'status': false,
    },
    {
      'image': 'assets/daily_offers/offer3.png',
      'name': 'Butterscotch shake',
      'description': '80 ml of glass and\n2 cup cakes',
      'price': '\$15.60',
      'offerPrice': '\$12.00',
      'status': true,
    },
    {
      'image': 'assets/daily_offers/offer4.png',
      'name': 'Special Indian Meal',
      'description':
          '2 Vegetables, Rise, Dal Makhani, 3 Roti, Curd, Salad & Papad',
      'price': '\$18.99',
      'offerPrice': '\$15.99',
      'status': true,
    },
    {
      'image': 'assets/daily_offers/offer5.png',
      'name': 'Fast Food',
      'description': 'Burger S- 1, sandwich S- 1,  Manchurian half',
      'price': '\$19.60',
      'offerPrice': '\$17.60',
      'status': false,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
        title: Text(
          'Daily Offers',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: dailyOffersList(),
    );
  }

  dailyOffersList() {
    return ListView.builder(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      itemCount: dailyOfferList.length,
      itemBuilder: (context, index) {
        final item = dailyOfferList[index];
        return Container(
          margin: EdgeInsets.symmetric(
              horizontal: fixPadding * 2.0, vertical: fixPadding),
          padding: EdgeInsets.symmetric(
            horizontal: fixPadding,
            vertical: 7,
          ),
          decoration: BoxDecoration(
            color: whiteColor,
            borderRadius: BorderRadius.circular(10.0),
            boxShadow: [
              BoxShadow(
                color: greyColor.withOpacity(0.1),
                spreadRadius: 2.5,
                blurRadius: 2.5,
              ),
            ],
          ),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    height: 70.0,
                    width: 70.0,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5.0),
                      image: DecorationImage(
                        image: AssetImage(item['image']),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  widthSpace,
                  widthSpace,
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: EdgeInsets.only(bottom: 10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                item['price'],
                                style: greyColor12MediumLineThroughTextStyle,
                              ),
                              SizedBox(width: 3),
                              Text(
                                item['offerPrice'],
                                style: primaryColor12MediumTextStyle,
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.only(right: fixPadding * 3.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item['name'],
                                style: darkBlueColor14SemiBoldTextStyle,
                              ),
                              heightSpace,
                              Text(
                                item['description'],
                                style: greyColor11RegularTextStyle,
                              ),
                            ],
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.only(top: 10.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    item['status'] = false;
                                  });
                                },
                                child: Container(
                                  height: 22.0,
                                  width: 38.0,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color: item['status']
                                        ? whiteColor
                                        : primaryColor,
                                    border: Border.all(color: primaryColor),
                                    borderRadius: BorderRadius.only(
                                      topLeft: Radius.circular(3.0),
                                      bottomLeft: Radius.circular(3.0),
                                    ),
                                  ),
                                  child: Text(
                                    'OFF',
                                    style: TextStyle(
                                      color: item['status']
                                          ? primaryColor
                                          : whiteColor,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    item['status'] = true;
                                  });
                                },
                                child: Container(
                                  height: 22.0,
                                  width: 38.0,
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color: item['status']
                                        ? primaryColor
                                        : whiteColor,
                                    border: Border.all(color: primaryColor),
                                    borderRadius: BorderRadius.only(
                                      topRight: Radius.circular(3.0),
                                      bottomRight: Radius.circular(3.0),
                                    ),
                                  ),
                                  child: Text(
                                    'ON',
                                    style: TextStyle(
                                      color: item['status']
                                          ? whiteColor
                                          : primaryColor,
                                      fontSize: 11,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  )
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}
