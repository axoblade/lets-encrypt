import 'package:flutter/material.dart';
import 'package:foodex_restaurant_app/pages/screen.dart';

const Color primaryColor = Color(0xffff4200);
const Color bgColor = Color(0xffF0F1F8);
const Color lightBlueColor = Color(0xffDEE2EB);
const Color darkBlueColor = Color(0xff022e4c);
const Color whiteColor = Colors.white;
const Color blackColor = Colors.black;
const Color greyColor = Colors.grey;

const double fixPadding = 10.0;

const SizedBox heightSpace = SizedBox(height: 5.0);
const SizedBox widthSpace = SizedBox(width: 5.0);

TextStyle darkBlueColor22BoldTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 22,
  fontWeight: FontWeight.w700,
);

TextStyle whiteColor20BoldTextStyle = TextStyle(
  color: whiteColor,
  fontSize: 20,
  fontWeight: FontWeight.w700,
);

TextStyle darkBlueColor20BoldTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 20,
  fontWeight: FontWeight.w700,
);

TextStyle darkBlueColor18SemiBoldTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 18,
  fontWeight: FontWeight.w600,
);

TextStyle darkBlueColor17SemiBoldTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 17,
  fontWeight: FontWeight.w600,
);

TextStyle greyColor16MediumTextStyle = TextStyle(
  color: greyColor,
  fontSize: 16,
  fontWeight: FontWeight.w500,
);

TextStyle greyColor15MediumTextStyle = TextStyle(
  color: greyColor,
  fontSize: 15,
  fontWeight: FontWeight.w500,
);

TextStyle whiteColor15BoldTextStyle = TextStyle(
  color: whiteColor,
  fontSize: 15,
  fontWeight: FontWeight.w700,
);

TextStyle darkBlueColor15SemiBoldTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);

TextStyle primaryColor15SemiBoldTextStyle = TextStyle(
  color: primaryColor,
  fontSize: 15,
  fontWeight: FontWeight.w600,
);

TextStyle primaryColor15BoldTextStyle = TextStyle(
  color: primaryColor,
  fontSize: 15,
  fontWeight: FontWeight.w700,
);

TextStyle greyColor14MediumTextStyle = TextStyle(
  color: greyColor,
  fontSize: 14,
  fontWeight: FontWeight.w500,
);

TextStyle greyColor14SemiBoldTextStyle = TextStyle(
  color: greyColor,
  fontSize: 14,
  fontWeight: FontWeight.w600,
);

TextStyle darkBlueColor14SemiBoldTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 14,
  fontWeight: FontWeight.w600,
);

TextStyle primaryColor14MediumTextStyle = TextStyle(
  color: primaryColor,
  fontSize: 14,
  fontWeight: FontWeight.w500,
);

TextStyle darkBlueColor13SemiBoldTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 13,
  fontWeight: FontWeight.w600,
);

TextStyle darkBlueColor13MediumTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 13,
  fontWeight: FontWeight.w500,
);

TextStyle greyColor13SemiBoldTextStyle = TextStyle(
  color: greyColor,
  fontSize: 13,
  fontWeight: FontWeight.w600,
);

TextStyle greyColor13RegularTextStyle = TextStyle(
  color: greyColor,
  fontSize: 13,
  fontWeight: FontWeight.w400,
);

TextStyle primaryColor13SemiBoldTextStyle = TextStyle(
  color: primaryColor,
  fontSize: 13,
  fontWeight: FontWeight.w600,
);

TextStyle greyColor13MediumTextStyle = TextStyle(
  color: greyColor,
  fontSize: 13,
  fontWeight: FontWeight.w500,
);

TextStyle greyColor12MediumLineThroughTextStyle = TextStyle(
  color: greyColor,
  fontSize: 12,
  fontWeight: FontWeight.w500,
  decoration: TextDecoration.lineThrough,
);

TextStyle darkBlueColor12SemiBoldTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 12,
  fontWeight: FontWeight.w600,
);

TextStyle whiteColor12MediumTextStyle = TextStyle(
  color: whiteColor,
  fontSize: 12,
  fontWeight: FontWeight.w500,
);

TextStyle primaryColor12MediumTextStyle = TextStyle(
  color: primaryColor,
  fontSize: 12,
  fontWeight: FontWeight.w500,
);

TextStyle primaryColor11SemiBoldTextStyle = TextStyle(
  color: primaryColor,
  fontSize: 11,
  fontWeight: FontWeight.w600,
);

TextStyle whiteColor11SemiBoldTextStyle = TextStyle(
  color: whiteColor,
  fontSize: 11,
  fontWeight: FontWeight.w600,
);

TextStyle greyColor11MediumTextStyle = TextStyle(
  color: greyColor,
  fontSize: 11,
  fontWeight: FontWeight.w500,
);

TextStyle darkBlueColor11MediumTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 11,
  fontWeight: FontWeight.w500,
);

TextStyle darkBlueColor11SemiBoldTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 11,
  fontWeight: FontWeight.w600,
);

TextStyle greyColor11RegularTextStyle = TextStyle(
  color: greyColor,
  fontSize: 11,
  fontWeight: FontWeight.w400,
);

TextStyle darkBlueColor11RegularTextStyle = TextStyle(
  color: darkBlueColor,
  fontSize: 11,
  fontWeight: FontWeight.w400,
);

TextStyle primaryColor11MediumItalicTextStyle = TextStyle(
  color: primaryColor,
  fontSize: 11,
  fontStyle: FontStyle.italic,
  fontWeight: FontWeight.w500,
);

TextStyle greyColorColor9SemiBoldTextStyle = TextStyle(
  color: greyColor,
  fontSize: 9,
  fontWeight: FontWeight.w600,
);

TextStyle greyColorColor9RegularTextStyle = TextStyle(
  color: greyColor,
  fontSize: 9,
  fontWeight: FontWeight.w400,
);

TextStyle whiteColor8MediumTextStyle = TextStyle(
  color: whiteColor,
  fontSize: 8,
  fontWeight: FontWeight.w500,
);
