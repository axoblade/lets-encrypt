import 'package:flutter/cupertino.dart';
import 'package:foodex_deliveryboy_app/pages/screen.dart';

class Settings extends StatefulWidget {
  @override
  _SettingsState createState() => _SettingsState();
}

class _SettingsState extends State<Settings> {
  bool notification = false;
  bool location = true;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
        title: Text(
          'Settings',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        padding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
        children: [
          notifications(),
          heightSpace,
          heightSpace,
          heightSpace,
          title('Clear Cache'),
          heightSpace,
          heightSpace,
          heightSpace,
          shareLocation(),
          heightSpace,
          heightSpace,
          heightSpace,
          title('Terms of user'),
          heightSpace,
          heightSpace,
          heightSpace,
          heightSpace,
          heightSpace,
          title('Privacy policy'),
        ],
      ),
    );
  }

  notifications() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        title('Notifications'),
        Transform.scale(
          scale: 0.7,
          child: Container(
            child: CupertinoSwitch(
              activeColor: primaryColor,
              value: notification,
              onChanged: (bool value) {
                setState(() {
                  notification = value;
                });
              },
            ),
          ),
        ),
      ],
    );
  }

  shareLocation() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        title('I agree to share my location'),
        Transform.scale(
          scale: 0.7,
          child: Container(
            child: CupertinoSwitch(
              activeColor: primaryColor,
              value: location,
              onChanged: (bool value) {
                setState(() {
                  location = value;
                });
              },
            ),
          ),
        ),
      ],
    );
  }

  title(String title) {
    return Text(
      title,
      style: darkBlueColor14SemiBoldTextStyle,
    );
  }
}
