import 'package:flutter/cupertino.dart';
import 'package:foodex_deliveryboy_app/pages/screen.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  double height;
  double width;
  bool online = false;
  GoogleMapController mapController;

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Stack(
        children: [
          googleMap(),
          topCard(),
          bottomCard(),
        ],
      ),
    );
  }

  googleMap() {
    return Container(
      height: height,
      width: width,
      child: GoogleMap(
        initialCameraPosition: CameraPosition(
          target: LatLng(18.495351, -69.949366),
          zoom: 14,
        ),
        onMapCreated: (GoogleMapController controller) {
          mapController = controller;
        },
      ),
    );
  }

  topCard() {
    return Positioned(
      top: 80.0,
      left: 20.0,
      right: 20.0,
      child: Container(
        padding: EdgeInsets.symmetric(
          horizontal: fixPadding,
          vertical: 3.0,
        ),
        decoration: BoxDecoration(
          color: bgColor,
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              online ? 'You\'re Online' : 'You\'re Offline',
              style: darkBlueColor16SemiBoldTextStyle,
            ),
            Transform.scale(
              scale: 0.6,
              child: Container(
                child: CupertinoSwitch(
                  activeColor: primaryColor,
                  value: online,
                  onChanged: (bool value) {
                    setState(() {
                      online = value;
                    });
                  },
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  bottomCard() {
    return Positioned(
      bottom: 0.0,
      left: 0.0,
      right: 0.0,
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => AvailableDelivery()),
        ),
        child: Container(
          padding: EdgeInsets.symmetric(
            horizontal: fixPadding * 2.0,
            vertical: fixPadding,
          ),
          color: bgColor,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Available Deliveries',
                style: darkBlueColor15SemiBoldTextStyle,
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: greyColor,
                size: 15,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
