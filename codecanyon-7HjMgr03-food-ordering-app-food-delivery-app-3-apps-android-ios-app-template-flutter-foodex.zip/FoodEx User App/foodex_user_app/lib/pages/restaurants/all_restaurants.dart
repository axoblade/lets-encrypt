import 'package:foodex_user_app/pages/screen.dart';

class AllRestaurants extends StatelessWidget {
  final restaurantList = [
    {
      'logo': 'assets/restaurants_logo/logo1.png',
      'name': 'Marine Rise Restaurant',
      'rating': '4.3',
      'foodType': 'Fast food,Italian,Chinese',
      'distance': '2.5',
      'address': '1124, Church Street, New york, USA',
    },
    {
      'logo': 'assets/restaurants_logo/logo2.png',
      'name': 'Food Junction Restaurant',
      'rating': '4.1',
      'foodType': 'Fast food,Italian,Chinese',
      'distance': '2.8',
      'address': '1124, Church Street, New york, USA',
    },
    {
      'logo': 'assets/restaurants_logo/logo3.png',
      'name': 'Sevan Star Restaurant',
      'rating': '4.0',
      'foodType': 'Fast food,Italian,Chinese',
      'distance': '3.50',
      'address': '1124, Church Street, New york, USA',
    },
    {
      'logo': 'assets/restaurants_logo/logo4.png',
      'name': 'Hunger Spot',
      'rating': '4.0',
      'foodType': 'Fast food,Italian,Chinese',
      'distance': '3.5',
      'address': '1124, Church Street, New york, USA',
    },
    {
      'logo': 'assets/restaurants_logo/logo5.png',
      'name': 'Fishchef',
      'rating': '3.5',
      'foodType': 'Sea food',
      'distance': '4.0',
      'address': '1124, Church Street, New york, USA',
    },
    {
      'logo': 'assets/restaurants_logo/logo6.png',
      'name': 'Food by Jesica',
      'rating': '3.0',
      'foodType': 'Fast food,Pizza',
      'distance': '4.5',
      'address': '1124, Church Street, New york, USA',
    },
    {
      'logo': 'assets/restaurants_logo/logo7.png',
      'name': 'King Of Foods',
      'rating': '2.0',
      'foodType': 'ChineseFast food',
      'distance': '5.0',
      'address': '1124, Church Street, New york, USA',
    },
    {
      'logo': 'assets/restaurants_logo/logo3.png',
      'name': 'Sevan Star Restaurant',
      'rating': '4.0',
      'foodType': 'Fast food,Italian,Chinese',
      'distance': '3.0',
      'address': '1124, Church Street, New york, USA',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(
            Icons.arrow_back_ios,
          ),
        ),
        actions: [
          Container(
            margin: EdgeInsets.only(right: fixPadding * 2.0),
            child: IconButton(
              onPressed: () {},
              icon: Icon(
                Icons.search,
              ),
              iconSize: 20,
            ),
          ),
        ],
      ),
      body: restaurantsList(),
    );
  }

  restaurantsList() {
    return ListView.builder(
      physics: BouncingScrollPhysics(),
      itemCount: restaurantList.length,
      itemBuilder: (context, index) {
        final item = restaurantList[index];
        return Padding(
          padding: const EdgeInsets.fromLTRB(
            fixPadding * 2.0,
            fixPadding,
            fixPadding * 2.0,
            fixPadding,
          ),
          child: InkWell(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    RestaurantDetails(tag: restaurantList[index]),
              ),
            ),
            child: Container(
              padding: EdgeInsets.all(fixPadding),
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [
                  BoxShadow(
                    color: greyColor.withOpacity(0.1),
                    spreadRadius: 2.5,
                    blurRadius: 2.5,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Hero(
                        tag: restaurantList[index],
                        child: Container(
                          height: 40,
                          width: 40,
                          decoration: BoxDecoration(
                            color: Color(0xffe6e6e6),
                            borderRadius: BorderRadius.circular(5.0),
                            image: DecorationImage(
                              image: AssetImage(item['logo']),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      widthSpace,
                      widthSpace,
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  item['name'],
                                  style: darkBlueColor14SemiBoldTextStyle,
                                ),
                                Row(
                                  children: [
                                    Text(
                                      item['rating'],
                                      style: primaryColor13SemiBoldTextStyle,
                                    ),
                                    widthSpace,
                                    Icon(
                                      Icons.star,
                                      color: primaryColor,
                                      size: 15,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              item['foodType'],
                              style: greyColor14MediumTextStyle,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  heightSpace,
                  Row(
                    children: [
                      widthSpace,
                      widthSpace,
                      Icon(
                        Icons.location_on,
                        color: primaryColor,
                        size: 15,
                      ),
                      widthSpace,
                      Text(
                        '${item['distance']} km',
                        style: greyColor13MediumTextStyle,
                      ),
                      widthSpace,
                      verticalDivider(),
                      widthSpace,
                      Text(
                        item['address'],
                        style: greyColor13MediumTextStyle,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  verticalDivider() {
    return Container(
      color: greyColor,
      height: 11.0,
      width: 1.5,
    );
  }
}
