import 'package:foodex_deliveryboy_app/pages/screen.dart';
import 'package:foodex_deliveryboy_app/widget/column_builder.dart';

class Earnings extends StatefulWidget {
  @override
  _EarningsState createState() => _EarningsState();
}

class _EarningsState extends State<Earnings> {
  final todayEarningList = [
    {
      'orderId': 'ACR147852',
      'date': '02-02-2021',
      'amount': '\$32.00',
    },
    {
      'orderId': 'FTR159874',
      'date': '02-02-2021',
      'amount': '\$30.00',
    },
    {
      'orderId': 'BHT123698',
      'date': '02-02-2021',
      'amount': '\$40.00',
    },
    {
      'orderId': 'NHJ159856',
      'date': '02-02-2021',
      'amount': '\$36.00',
    },
  ];

  final yesterdayEarningList = [
    {
      'orderId': 'GTS123654',
      'date': '01-02-2021',
      'amount': '\$28.00',
    },
    {
      'orderId': 'FST123698',
      'date': '01-02-2021',
      'amount': '\$30.00',
    },
    {
      'orderId': 'BHT123698',
      'date': '01-02-2021',
      'amount': '\$40.00',
    },
    {
      'orderId': 'NHJ159856',
      'date': '01-02-2021',
      'amount': '\$36.00',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          'Earnings',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        children: [
          title('Today'),
          todayEarnings(),
          title('Yesterday'),
          yesterdayEarnings(),
        ],
      ),
    );
  }

  title(String title) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: fixPadding * 2.0,
        vertical: fixPadding,
      ),
      color: lightBlueColor,
      child: Text(
        title,
        style: darkBlueColor15SemiBoldTextStyle,
      ),
    );
  }

  todayEarnings() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        earning(
          day: 'Today',
          date: '02 Feb, 2021',
          earning: '\$138.00',
        ),
        ColumnBuilder(
          itemCount: todayEarningList.length,
          itemBuilder: (context, index) {
            final item = todayEarningList[index];
            return Container(
              margin: EdgeInsets.fromLTRB(
                  fixPadding * 2.0, 0.0, fixPadding * 2.0, fixPadding * 1.6),
              padding: EdgeInsets.fromLTRB(6.0, 5.0, 6.0, fixPadding),
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [
                  BoxShadow(
                    color: greyColor.withOpacity(0.1),
                    spreadRadius: 2.5,
                    blurRadius: 2.5,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text(
                        'Order ID: ',
                        style: greyColor12MediumTextStyle,
                      ),
                      Text(
                        item['orderId'],
                        style: darkBlueColor14SemiBoldTextStyle,
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        'Date: ',
                        style: greyColor12MediumTextStyle,
                      ),
                      Text(
                        item['date'],
                        style: darkBlueColor14SemiBoldTextStyle,
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        item['amount'],
                        style: primaryColor14SemiBoldTextStyle,
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  yesterdayEarnings() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        earning(
          day: 'Today',
          date: '01 Feb, 2021',
          earning: '\$134.00',
        ),
        ColumnBuilder(
          itemCount: yesterdayEarningList.length,
          itemBuilder: (context, index) {
            final item = yesterdayEarningList[index];
            return Container(
              margin: EdgeInsets.fromLTRB(
                  fixPadding * 2.0, 0.0, fixPadding * 2.0, fixPadding * 1.6),
              padding: EdgeInsets.fromLTRB(6.0, 5.0, 6.0, fixPadding),
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [
                  BoxShadow(
                    color: greyColor.withOpacity(0.1),
                    spreadRadius: 2.5,
                    blurRadius: 2.5,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text(
                        'Order ID: ',
                        style: greyColor12MediumTextStyle,
                      ),
                      Text(
                        item['orderId'],
                        style: darkBlueColor14SemiBoldTextStyle,
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        'Date: ',
                        style: greyColor12MediumTextStyle,
                      ),
                      Text(
                        item['date'],
                        style: darkBlueColor14SemiBoldTextStyle,
                      ),
                    ],
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        item['amount'],
                        style: primaryColor14SemiBoldTextStyle,
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  earning({String day, earning, date}) {
    return Container(
      margin: EdgeInsets.all(fixPadding * 2.0),
      padding: EdgeInsets.fromLTRB(fixPadding, 5.0, fixPadding * 3.0, 5.0),
      decoration: BoxDecoration(
        color: darkBlueColor,
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            day,
            style: whiteColor12SemiBoldTextStyle,
          ),
          SizedBox(height: 8),
          Text(
            earning,
            style: whiteColor15SemiBoldTextStyle,
          ),
          SizedBox(height: 2),
          Text(
            date,
            style: whiteColor11MediumTextStyle,
          ),
        ],
      ),
    );
  }
}
