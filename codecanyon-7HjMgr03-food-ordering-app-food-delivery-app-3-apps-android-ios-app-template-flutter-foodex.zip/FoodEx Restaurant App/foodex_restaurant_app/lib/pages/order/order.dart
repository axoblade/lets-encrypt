import 'package:foodex_restaurant_app/pages/screen.dart';

class Order extends StatefulWidget {
  @override
  _OrderState createState() => _OrderState();
}

class _OrderState extends State<Order> {
  String isSelected = 'new';
  String dropdownValue;

  final newOrderList = [
    {
      'image': 'assets/users/user5.png',
      'name': 'Samantha John',
      'orderId': 'ACR123654',
      'date': 'Today',
      'time': '12:05 am',
      'payment': '\$42.00',
      'orderCount': 3,
      'item1': 'Veg Sandwich',
      'qnt1': '1',
      'amount1': '\$6.00',
      'item2': 'Veg Frankie',
      'qnt2': '2',
      'amount2': '\$20.00',
      'item3': 'Margherite Pizza',
      'qnt3': '1',
      'amount3': '\$12.00',
      'totalAmount': '\$38.00',
      'tax': '\$2.50',
      'charge': '\$1.50',
      'note':
          'Hi, please pack green sauce in my order and please tell your delivery boy that he have to come on 2nd floor because i’m not at home.',
    },
    {
      'image': 'assets/users/user6.png',
      'name': 'Krish Doe',
      'orderId': 'ACR123654',
      'date': 'Today',
      'time': '12:01 am',
      'payment': '\$42.00',
      'orderCount': 3,
      'item1': 'Veg Sandwich',
      'qnt1': '1',
      'amount1': '\$6.00',
      'item2': 'Veg Frankie',
      'qnt2': '2',
      'amount2': '\$20.00',
      'item3': 'Margherite Pizza',
      'qnt3': '1',
      'amount3': '\$12.00',
      'totalAmount': '\$38.00',
      'tax': '\$2.50',
      'charge': '\$1.50',
      'note':
          'Hi, please pack green sauce in my order and please tell your delivery boy that he have to come on 2nd floor because i’m not at home.',
    },
  ];

  final ongoingOrderList = [
    {
      'image': 'assets/users/user5.png',
      'name': 'Samantha John',
      'orderId': 'ACR123654',
      'date': 'Today',
      'time': '12:05 am',
      'payment': '\$42.00',
      'orderCount': 3,
      'item1': 'Veg Sandwich',
      'qnt1': '1',
      'amount1': '\$6.00',
      'item2': 'Veg Frankie',
      'qnt2': '2',
      'amount2': '\$20.00',
      'item3': 'Margherite Pizza',
      'qnt3': '1',
      'amount3': '\$12.00',
      'totalAmount': '\$38.00',
      'tax': '\$2.50',
      'charge': '\$1.50',
      'orderStatus': 'Order Dispatched',
    },
    {
      'image': 'assets/users/user6.png',
      'name': 'Krish Doe',
      'orderId': 'ACR123654',
      'date': 'Today',
      'time': '12:01 am',
      'payment': '\$42.00',
      'orderCount': 3,
      'item1': 'Veg Sandwich',
      'qnt1': '1',
      'amount1': '\$6.00',
      'item2': 'Veg Frankie',
      'qnt2': '2',
      'amount2': '\$20.00',
      'item3': 'Margherite Pizza',
      'qnt3': '1',
      'amount3': '\$12.00',
      'totalAmount': '\$38.00',
      'tax': '\$2.50',
      'charge': '\$1.50',
      'orderStatus': 'Order Preparing',
    },
    {
      'image': 'assets/users/user5.png',
      'name': 'Samantha John',
      'orderId': 'ACR123654',
      'date': 'Today',
      'time': '12:05 am',
      'payment': '\$42.00',
      'orderCount': 3,
      'item1': 'Veg Sandwich',
      'qnt1': '1',
      'amount1': '\$6.00',
      'item2': 'Veg Frankie',
      'qnt2': '2',
      'amount2': '\$20.00',
      'item3': 'Margherite Pizza',
      'qnt3': '1',
      'amount3': '\$12.00',
      'totalAmount': '\$38.00',
      'tax': '\$2.50',
      'charge': '\$1.50',
      'orderStatus': 'Order Dispatched',
    },
  ];

  final pastOrderList = [
    {
      'image': 'assets/users/user5.png',
      'name': 'Samantha John',
      'orderId': 'ACR123654',
      'date': 'Today',
      'time': '12:05 am',
      'payment': '\$42.00',
      'orderCount': 3,
      'item1': 'Veg Sandwich',
      'qnt1': '1',
      'amount1': '\$6.00',
      'item2': 'Veg Frankie',
      'qnt2': '2',
      'amount2': '\$20.00',
      'item3': 'Margherite Pizza',
      'qnt3': '1',
      'amount3': '\$12.00',
      'totalAmount': '\$38.00',
      'tax': '\$2.50',
      'charge': '\$1.50',
      'orderStatus': 'Order Delivered',
    },
    {
      'image': 'assets/users/user6.png',
      'name': 'Krish Doe',
      'orderId': 'ACR123654',
      'date': 'Today',
      'time': '12:01 am',
      'payment': '\$42.00',
      'orderCount': 3,
      'item1': 'Veg Sandwich',
      'qnt1': '1',
      'amount1': '\$6.00',
      'item2': 'Veg Frankie',
      'qnt2': '2',
      'amount2': '\$20.00',
      'item3': 'Margherite Pizza',
      'qnt3': '1',
      'amount3': '\$12.00',
      'totalAmount': '\$38.00',
      'tax': '\$2.50',
      'charge': '\$1.50',
      'orderStatus': 'Order Cancelled',
    },
    {
      'image': 'assets/users/user5.png',
      'name': 'Samantha John',
      'orderId': 'ACR123654',
      'date': 'Today',
      'time': '12:05 am',
      'payment': '\$42.00',
      'orderCount': 3,
      'item1': 'Veg Sandwich',
      'qnt1': '1',
      'amount1': '\$6.00',
      'item2': 'Veg Frankie',
      'qnt2': '2',
      'amount2': '\$20.00',
      'item3': 'Margherite Pizza',
      'qnt3': '1',
      'amount3': '\$12.00',
      'totalAmount': '\$38.00',
      'tax': '\$2.50',
      'charge': '\$1.50',
      'orderStatus': 'Order Delivered',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          'Orders',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: Column(
        children: [
          orderMenu(),
          isSelected == 'new'
              ? newOrdersList()
              : isSelected == 'ongoing'
                  ? ongoingOrdersList()
                  : pastOrdersList(),
        ],
      ),
    );
  }

  orderMenu() {
    return Container(
      color: lightBlueColor,
      margin: EdgeInsets.only(top: fixPadding),
      padding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          InkWell(
            onTap: () {
              setState(() {
                isSelected = 'new';
              });
            },
            child: Container(
              padding: EdgeInsets.symmetric(vertical: fixPadding),
              decoration: BoxDecoration(
                border: isSelected == 'new'
                    ? Border(bottom: BorderSide(color: darkBlueColor))
                    : null,
              ),
              child: Text(
                'New Orders',
                style: darkBlueColor14SemiBoldTextStyle,
              ),
            ),
          ),
          InkWell(
            onTap: () {
              setState(() {
                isSelected = 'ongoing';
              });
            },
            child: Container(
              padding: EdgeInsets.all(fixPadding),
              decoration: BoxDecoration(
                border: isSelected == 'ongoing'
                    ? Border(bottom: BorderSide(color: darkBlueColor))
                    : null,
              ),
              child: Text(
                'Ongoing Orders',
                style: darkBlueColor14SemiBoldTextStyle,
              ),
            ),
          ),
          InkWell(
            onTap: () {
              setState(() {
                isSelected = 'past';
              });
            },
            child: Container(
              padding: EdgeInsets.all(fixPadding),
              decoration: BoxDecoration(
                border: isSelected == 'past'
                    ? Border(bottom: BorderSide(color: darkBlueColor))
                    : null,
              ),
              child: Text(
                'Past Orders',
                style: darkBlueColor14SemiBoldTextStyle,
              ),
            ),
          ),
        ],
      ),
    );
  }

  newOrdersList() {
    return Expanded(
      child: ListView.builder(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        itemCount: newOrderList.length,
        itemBuilder: (context, index) {
          final item = newOrderList[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(
              fixPadding * 2.0,
              index == 0 ? fixPadding * 2.0 : fixPadding,
              fixPadding * 2.0,
              fixPadding,
            ),
            child: InkWell(
              onTap: () => newOrderDetails(),
              child: Container(
                decoration: BoxDecoration(
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: greyColor.withOpacity(0.1),
                      spreadRadius: 2.5,
                      blurRadius: 2.5,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(fixPadding),
                      decoration: BoxDecoration(
                        color: greyColor.withOpacity(0.2),
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10),
                          topLeft: Radius.circular(10),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            height: 45.0,
                            width: 45.0,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                image: AssetImage(item['image']),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          widthSpace,
                          widthSpace,
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      item['name'],
                                      style: darkBlueColor15SemiBoldTextStyle,
                                    ),
                                    Text(
                                      'Order Id: ${item['orderId']}',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      '${item['date']} at ${item['time']}',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                    Text(
                                      'Total Payment: ${item['payment']}',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: fixPadding,
                        vertical: fixPadding * 1.5,
                      ),
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(10),
                          bottomLeft: Radius.circular(10),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          orderInformationRow(
                            title: 'Order Items',
                            information1: 'Qnt.',
                            information2: 'Amount',
                            style: darkBlueColor13SemiBoldTextStyle,
                          ),
                          SizedBox(height: 8),
                          orderInformationRow(
                            title: item['item1'],
                            information1: item['qnt1'],
                            information2: item['amount1'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: item['item2'],
                            information1: item['qnt2'],
                            information2: item['amount2'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: item['item3'],
                            information1: item['qnt3'],
                            information2: item['amount3'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: 'TotalAmount',
                            information1: '',
                            information2: item['totalAmount'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          SizedBox(height: 7),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Service Tax: ',
                                style: greyColor11MediumTextStyle,
                              ),
                              Text(
                                item['tax'],
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 2),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Delivery Charge: ',
                                style: greyColor11MediumTextStyle,
                              ),
                              Text(
                                item['charge'],
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          divider(),
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: 'Note: ',
                                  style: greyColorColor9SemiBoldTextStyle,
                                ),
                                TextSpan(
                                  text: item['note'],
                                  style: greyColorColor9RegularTextStyle,
                                ),
                              ],
                            ),
                          ),
                          heightSpace,
                          heightSpace,
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Container(
                                    padding: EdgeInsets.all(6.0),
                                    decoration: BoxDecoration(
                                      color: whiteColor,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: greyColor.withOpacity(0.1),
                                          spreadRadius: 2.5,
                                          blurRadius: 2.5,
                                        ),
                                      ],
                                    ),
                                    child: Image.asset(
                                      'assets/icons/order_detail.png',
                                      height: 18,
                                      width: 18,
                                    ),
                                    // Icon(
                                    //   Icons.event_note,
                                    //   color: darkBlueColor,
                                    //   size: 18,
                                    // ),
                                  ),
                                  widthSpace,
                                  widthSpace,
                                  Container(
                                    padding: EdgeInsets.all(6.0),
                                    decoration: BoxDecoration(
                                      color: whiteColor,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: greyColor.withOpacity(0.1),
                                          spreadRadius: 2.5,
                                          blurRadius: 2.5,
                                        ),
                                      ],
                                    ),
                                    child: Icon(
                                      Icons.call,
                                      color: darkBlueColor,
                                      size: 18,
                                    ),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                  InkWell(
                                    onTap: () {},
                                    child: Container(
                                      padding: EdgeInsets.all(fixPadding),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        border: Border.all(color: primaryColor),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Text(
                                        'Cancel Order',
                                        style: primaryColor12MediumTextStyle,
                                      ),
                                    ),
                                  ),
                                  widthSpace,
                                  widthSpace,
                                  InkWell(
                                    onTap: () {},
                                    child: Container(
                                      padding: EdgeInsets.all(fixPadding),
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        color: primaryColor,
                                        border: Border.all(color: primaryColor),
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      child: Text(
                                        'Accept Order',
                                        style: whiteColor12MediumTextStyle,
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  newOrderDetails() {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Wrap(
            children: [
              Container(
                decoration: BoxDecoration(
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: greyColor.withOpacity(0.1),
                      spreadRadius: 2.5,
                      blurRadius: 2.5,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(fixPadding),
                      decoration: BoxDecoration(
                        color: greyColor.withOpacity(0.2),
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10),
                          topLeft: Radius.circular(10),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            height: 45.0,
                            width: 45.0,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                image: AssetImage('assets/users/user5.png'),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          widthSpace,
                          widthSpace,
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Samantha John',
                                      style: darkBlueColor15SemiBoldTextStyle,
                                    ),
                                    Text(
                                      'Order Id: ACR123654',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Today at 12:05 am',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                    Text(
                                      'Total Payment: \$42.00',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: fixPadding,
                        vertical: fixPadding * 1.5,
                      ),
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(10),
                          bottomLeft: Radius.circular(10),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.call,
                                color: darkBlueColor,
                                size: 16,
                              ),
                              widthSpace,
                              widthSpace,
                              Text(
                                '(+91) 1234567890',
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          heightSpace,
                          heightSpace,
                          Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Icon(
                                Icons.location_on,
                                color: darkBlueColor,
                                size: 16,
                              ),
                              widthSpace,
                              widthSpace,
                              Expanded(
                                child: Text(
                                  'B 441, Old city town, Leminton street\nNear City Part, Washington DC,\nUnited States Of America',
                                  style: darkBlueColor11MediumTextStyle,
                                ),
                              ),
                            ],
                          ),
                          heightSpace,
                          heightSpace,
                          Row(
                            children: [
                              Icon(
                                Icons.mail,
                                color: darkBlueColor,
                                size: 16,
                              ),
                              widthSpace,
                              widthSpace,
                              Text(
                                'johnsamantha@gmail.com',
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          divider(),
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: 'Note: ',
                                  style: greyColorColor9SemiBoldTextStyle,
                                ),
                                TextSpan(
                                  text:
                                      'Hi, please pack green sauce in my order and please tell your delivery boy that he have to come on 2nd floor because i’m not at home.',
                                  style: greyColorColor9RegularTextStyle,
                                ),
                              ],
                            ),
                          ),
                          divider(),
                          orderInformationRow(
                            title: 'Order Items',
                            information1: 'Qnt.',
                            information2: 'Amount',
                            style: darkBlueColor13SemiBoldTextStyle,
                          ),
                          SizedBox(height: 8),
                          orderInformationRow(
                            title: 'Veg Sandwich',
                            information1: '1',
                            information2: '\$6.00',
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: 'Veg Frankie',
                            information1: '2',
                            information2: '\$20.00',
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: 'Margherite Pizza',
                            information1: '1',
                            information2: '\$12.00',
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: 'TotalAmount',
                            information1: '',
                            information2: '\$38.00',
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          SizedBox(height: 7),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Service Tax: ',
                                style: greyColor11MediumTextStyle,
                              ),
                              Text(
                                '\$2.50',
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 2),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Delivery Charge: ',
                                style: greyColor11MediumTextStyle,
                              ),
                              Text(
                                '\$1.50',
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          heightSpace,
                          heightSpace,
                          Row(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              InkWell(
                                onTap: () => Navigator.pop(context),
                                child: Container(
                                  padding: EdgeInsets.all(fixPadding),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    border: Border.all(color: primaryColor),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Text(
                                    'Cancel Order',
                                    style: primaryColor12MediumTextStyle,
                                  ),
                                ),
                              ),
                              widthSpace,
                              widthSpace,
                              widthSpace,
                              InkWell(
                                onTap: () => Navigator.pop(context),
                                child: Container(
                                  padding: EdgeInsets.all(fixPadding),
                                  alignment: Alignment.center,
                                  decoration: BoxDecoration(
                                    color: primaryColor,
                                    border: Border.all(color: primaryColor),
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  child: Text(
                                    'Accept Order',
                                    style: whiteColor12MediumTextStyle,
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  ongoingOrdersList() {
    return Expanded(
      child: ListView.builder(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        itemCount: ongoingOrderList.length,
        itemBuilder: (context, index) {
          final item = ongoingOrderList[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(
              fixPadding * 2.0,
              index == 0 ? fixPadding * 2.0 : fixPadding,
              fixPadding * 2.0,
              fixPadding,
            ),
            child: InkWell(
              onTap: () => ongoingOrderDetails(item['orderStatus']),
              child: Container(
                decoration: BoxDecoration(
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: greyColor.withOpacity(0.1),
                      spreadRadius: 2.5,
                      blurRadius: 2.5,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(fixPadding),
                      decoration: BoxDecoration(
                        color: greyColor.withOpacity(0.2),
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10),
                          topLeft: Radius.circular(10),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            height: 45.0,
                            width: 45.0,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                image: AssetImage(item['image']),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          widthSpace,
                          widthSpace,
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      item['name'],
                                      style: darkBlueColor15SemiBoldTextStyle,
                                    ),
                                    Text(
                                      'Order Id: ${item['orderId']}',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      '${item['date']} at ${item['time']}',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                    Text(
                                      'Total Payment: ${item['payment']}',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: fixPadding,
                        vertical: fixPadding * 1.5,
                      ),
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(10),
                          bottomLeft: Radius.circular(10),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          orderInformationRow(
                            title: 'Order Items',
                            information1: 'Qnt.',
                            information2: 'Amount',
                            style: darkBlueColor13SemiBoldTextStyle,
                          ),
                          SizedBox(height: 8),
                          orderInformationRow(
                            title: item['item1'],
                            information1: item['qnt1'],
                            information2: item['amount1'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: item['item2'],
                            information1: item['qnt2'],
                            information2: item['amount2'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: item['item3'],
                            information1: item['qnt3'],
                            information2: item['amount3'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: 'TotalAmount',
                            information1: '',
                            information2: item['totalAmount'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          SizedBox(height: 7),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Service Tax: ',
                                style: greyColor11MediumTextStyle,
                              ),
                              Text(
                                item['tax'],
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 2),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Delivery Charge: ',
                                style: greyColor11MediumTextStyle,
                              ),
                              Text(
                                item['charge'],
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    'Order Status: ',
                                    style: darkBlueColor13SemiBoldTextStyle,
                                  ),
                                  DropdownButtonHideUnderline(
                                    child: DropdownButton(
                                      elevation: 0,
                                      isDense: true,
                                      hint: Text(
                                        item['orderStatus'],
                                        style: primaryColor13SemiBoldTextStyle,
                                      ),
                                      icon: Icon(
                                        Icons.keyboard_arrow_down,
                                        color: primaryColor,
                                        size: 20,
                                      ),
                                      value: item['orderStatus'],
                                      onChanged: (newValue) {
                                        setState(() {
                                          item['orderStatus'] = newValue;
                                        });
                                      },
                                      style: primaryColor13SemiBoldTextStyle,
                                      items: <String>[
                                        'Order Dispatched',
                                        'Order Preparing',
                                      ].map<DropdownMenuItem<String>>(
                                          (String value) {
                                        return DropdownMenuItem<String>(
                                          value: value,
                                          child: Text(value),
                                        );
                                      }).toList(),
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                padding: EdgeInsets.all(6.0),
                                decoration: BoxDecoration(
                                  color: whiteColor,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: greyColor.withOpacity(0.1),
                                      spreadRadius: 2.5,
                                      blurRadius: 2.5,
                                    ),
                                  ],
                                ),
                                child: Image.asset(
                                  'assets/icons/order_detail.png',
                                  height: 18,
                                  width: 18,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  ongoingOrderDetails(String status) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
            return Wrap(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: greyColor.withOpacity(0.1),
                        spreadRadius: 2.5,
                        blurRadius: 2.5,
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.all(fixPadding),
                        decoration: BoxDecoration(
                          color: greyColor.withOpacity(0.2),
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(10),
                            topLeft: Radius.circular(10),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              height: 45.0,
                              width: 45.0,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  image: AssetImage('assets/users/user5.png'),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            widthSpace,
                            widthSpace,
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Samantha John',
                                        style: darkBlueColor15SemiBoldTextStyle,
                                      ),
                                      Text(
                                        'Order Id: ACR123654',
                                        style: darkBlueColor11MediumTextStyle,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Today at 12:05 am',
                                        style: darkBlueColor11MediumTextStyle,
                                      ),
                                      Text(
                                        'Total Payment: \$42.00',
                                        style: darkBlueColor11MediumTextStyle,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: fixPadding,
                          vertical: fixPadding * 1.5,
                        ),
                        decoration: BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.call,
                                  color: darkBlueColor,
                                  size: 16,
                                ),
                                widthSpace,
                                widthSpace,
                                Text(
                                  '(+91) 1234567890',
                                  style: darkBlueColor11MediumTextStyle,
                                ),
                              ],
                            ),
                            heightSpace,
                            heightSpace,
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(
                                  Icons.location_on,
                                  color: darkBlueColor,
                                  size: 16,
                                ),
                                widthSpace,
                                widthSpace,
                                Expanded(
                                  child: Text(
                                    'B 441, Old city town, Leminton street\nNear City Part, Washington DC,\nUnited States Of America',
                                    style: darkBlueColor11MediumTextStyle,
                                  ),
                                ),
                              ],
                            ),
                            heightSpace,
                            heightSpace,
                            Row(
                              children: [
                                Icon(
                                  Icons.mail,
                                  color: darkBlueColor,
                                  size: 16,
                                ),
                                widthSpace,
                                widthSpace,
                                Text(
                                  'johnsamantha@gmail.com',
                                  style: darkBlueColor11MediumTextStyle,
                                ),
                              ],
                            ),
                            divider(),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: 'Note: ',
                                    style: greyColorColor9SemiBoldTextStyle,
                                  ),
                                  TextSpan(
                                    text:
                                        'Hi, please pack green sauce in my order and please tell your delivery boy that he have to come on 2nd floor because i’m not at home.',
                                    style: greyColorColor9RegularTextStyle,
                                  ),
                                ],
                              ),
                            ),
                            divider(),
                            orderInformationRow(
                              title: 'Order Items',
                              information1: 'Qnt.',
                              information2: 'Amount',
                              style: darkBlueColor13SemiBoldTextStyle,
                            ),
                            SizedBox(height: 8),
                            orderInformationRow(
                              title: 'Veg Sandwich',
                              information1: '1',
                              information2: '\$6.00',
                              style: darkBlueColor11MediumTextStyle,
                            ),
                            heightSpace,
                            orderInformationRow(
                              title: 'Veg Frankie',
                              information1: '2',
                              information2: '\$20.00',
                              style: darkBlueColor11MediumTextStyle,
                            ),
                            heightSpace,
                            orderInformationRow(
                              title: 'Margherite Pizza',
                              information1: '1',
                              information2: '\$12.00',
                              style: darkBlueColor11MediumTextStyle,
                            ),
                            heightSpace,
                            orderInformationRow(
                              title: 'TotalAmount',
                              information1: '',
                              information2: '\$38.00',
                              style: darkBlueColor11MediumTextStyle,
                            ),
                            SizedBox(height: 7),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  'Service Tax: ',
                                  style: greyColor11MediumTextStyle,
                                ),
                                Text(
                                  '\$2.50',
                                  style: darkBlueColor11MediumTextStyle,
                                ),
                              ],
                            ),
                            SizedBox(height: 2),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  'Delivery Charge: ',
                                  style: greyColor11MediumTextStyle,
                                ),
                                Text(
                                  '\$1.50',
                                  style: darkBlueColor11MediumTextStyle,
                                ),
                              ],
                            ),
                            heightSpace,
                            heightSpace,
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'Order Status: ',
                                      style: darkBlueColor13SemiBoldTextStyle,
                                    ),
                                    DropdownButtonHideUnderline(
                                      child: DropdownButton(
                                        elevation: 0,
                                        isDense: true,
                                        hint: Text(
                                          status,
                                          style:
                                              primaryColor13SemiBoldTextStyle,
                                        ),
                                        icon: Icon(
                                          Icons.keyboard_arrow_down,
                                          color: primaryColor,
                                          size: 20,
                                        ),
                                        value: dropdownValue,
                                        onChanged: (String newValue) {
                                          setState(() {
                                            dropdownValue = newValue;
                                          });
                                        },
                                        style: primaryColor13SemiBoldTextStyle,
                                        items: <String>[
                                          'Order Dispatched',
                                          'Order Preparing',
                                        ].map<DropdownMenuItem<String>>(
                                            (String value) {
                                          return DropdownMenuItem<String>(
                                            value: value,
                                            child: Text(value),
                                          );
                                        }).toList(),
                                      ),
                                    ),
                                  ],
                                ),
                                InkWell(
                                  onTap: () => Navigator.pop(context),
                                  child: Container(
                                    padding: EdgeInsets.all(fixPadding),
                                    alignment: Alignment.center,
                                    decoration: BoxDecoration(
                                      border: Border.all(color: primaryColor),
                                      borderRadius: BorderRadius.circular(10),
                                    ),
                                    child: Text(
                                      'Cancel Order',
                                      style: primaryColor12MediumTextStyle,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }),
        );
      },
    );
  }

  pastOrdersList() {
    return Expanded(
      child: ListView.builder(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        itemCount: pastOrderList.length,
        itemBuilder: (context, index) {
          final item = pastOrderList[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(
              fixPadding * 2.0,
              index == 0 ? fixPadding * 2.0 : fixPadding,
              fixPadding * 2.0,
              fixPadding,
            ),
            child: InkWell(
              onTap: () => pastOrderDetails(item['orderStatus']),
              child: Container(
                decoration: BoxDecoration(
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: greyColor.withOpacity(0.1),
                      spreadRadius: 2.5,
                      blurRadius: 2.5,
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    Container(
                      padding: EdgeInsets.all(fixPadding),
                      decoration: BoxDecoration(
                        color: greyColor.withOpacity(0.2),
                        borderRadius: BorderRadius.only(
                          topRight: Radius.circular(10),
                          topLeft: Radius.circular(10),
                        ),
                      ),
                      child: Row(
                        children: [
                          Container(
                            height: 45.0,
                            width: 45.0,
                            decoration: BoxDecoration(
                              shape: BoxShape.circle,
                              image: DecorationImage(
                                image: AssetImage(item['image']),
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          widthSpace,
                          widthSpace,
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      item['name'],
                                      style: darkBlueColor15SemiBoldTextStyle,
                                    ),
                                    Text(
                                      'Order Id: ${item['orderId']}',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                  ],
                                ),
                                Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      '${item['date']} at ${item['time']}',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                    Text(
                                      'Total Payment: ${item['payment']}',
                                      style: darkBlueColor11MediumTextStyle,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(
                        horizontal: fixPadding,
                        vertical: fixPadding * 1.5,
                      ),
                      decoration: BoxDecoration(
                        color: whiteColor,
                        borderRadius: BorderRadius.only(
                          bottomRight: Radius.circular(10),
                          bottomLeft: Radius.circular(10),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          orderInformationRow(
                            title: 'Order Items',
                            information1: 'Qnt.',
                            information2: 'Amount',
                            style: darkBlueColor13SemiBoldTextStyle,
                          ),
                          SizedBox(height: 8),
                          orderInformationRow(
                            title: item['item1'],
                            information1: item['qnt1'],
                            information2: item['amount1'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: item['item2'],
                            information1: item['qnt2'],
                            information2: item['amount2'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: item['item3'],
                            information1: item['qnt3'],
                            information2: item['amount3'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          heightSpace,
                          orderInformationRow(
                            title: 'TotalAmount',
                            information1: '',
                            information2: item['totalAmount'],
                            style: darkBlueColor11MediumTextStyle,
                          ),
                          SizedBox(height: 7),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Service Tax: ',
                                style: greyColor11MediumTextStyle,
                              ),
                              Text(
                                item['tax'],
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          SizedBox(height: 2),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Text(
                                'Delivery Charge: ',
                                style: greyColor11MediumTextStyle,
                              ),
                              Text(
                                item['charge'],
                                style: darkBlueColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          divider(),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                children: [
                                  Text(
                                    'Order Status: ',
                                    style: darkBlueColor13SemiBoldTextStyle,
                                  ),
                                  Text(
                                    item['orderStatus'],
                                    style: TextStyle(
                                      color: item['orderStatus'] ==
                                              'Order Delivered'
                                          ? primaryColor
                                          : greyColor,
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                    ),
                                  ),
                                ],
                              ),
                              Container(
                                padding: EdgeInsets.all(6.0),
                                decoration: BoxDecoration(
                                  color: whiteColor,
                                  shape: BoxShape.circle,
                                  boxShadow: [
                                    BoxShadow(
                                      color: greyColor.withOpacity(0.1),
                                      spreadRadius: 2.5,
                                      blurRadius: 2.5,
                                    ),
                                  ],
                                ),
                                child: Image.asset(
                                  'assets/icons/order_detail.png',
                                  height: 18,
                                  width: 18,
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  pastOrderDetails(String status) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 2.0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
            return Wrap(
              children: [
                Container(
                  decoration: BoxDecoration(
                    color: whiteColor,
                    borderRadius: BorderRadius.circular(10),
                    boxShadow: [
                      BoxShadow(
                        color: greyColor.withOpacity(0.1),
                        spreadRadius: 2.5,
                        blurRadius: 2.5,
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Container(
                        padding: EdgeInsets.all(fixPadding),
                        decoration: BoxDecoration(
                          color: greyColor.withOpacity(0.2),
                          borderRadius: BorderRadius.only(
                            topRight: Radius.circular(10),
                            topLeft: Radius.circular(10),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              height: 45.0,
                              width: 45.0,
                              decoration: BoxDecoration(
                                shape: BoxShape.circle,
                                image: DecorationImage(
                                  image: AssetImage('assets/users/user5.png'),
                                  fit: BoxFit.cover,
                                ),
                              ),
                            ),
                            widthSpace,
                            widthSpace,
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Samantha John',
                                        style: darkBlueColor15SemiBoldTextStyle,
                                      ),
                                      Text(
                                        'Order Id: ACR123654',
                                        style: darkBlueColor11MediumTextStyle,
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Text(
                                        'Today at 12:05 am',
                                        style: darkBlueColor11MediumTextStyle,
                                      ),
                                      Text(
                                        'Total Payment: \$42.00',
                                        style: darkBlueColor11MediumTextStyle,
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Container(
                        padding: EdgeInsets.symmetric(
                          horizontal: fixPadding,
                          vertical: fixPadding * 1.5,
                        ),
                        decoration: BoxDecoration(
                          color: whiteColor,
                          borderRadius: BorderRadius.only(
                            bottomRight: Radius.circular(10),
                            bottomLeft: Radius.circular(10),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Icon(
                                  Icons.call,
                                  color: darkBlueColor,
                                  size: 16,
                                ),
                                widthSpace,
                                widthSpace,
                                Text(
                                  '(+91) 1234567890',
                                  style: darkBlueColor11MediumTextStyle,
                                ),
                              ],
                            ),
                            heightSpace,
                            heightSpace,
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Icon(
                                  Icons.location_on,
                                  color: darkBlueColor,
                                  size: 16,
                                ),
                                widthSpace,
                                widthSpace,
                                Expanded(
                                  child: Text(
                                    'B 441, Old city town, Leminton street\nNear City Part, Washington DC,\nUnited States Of America',
                                    style: darkBlueColor11MediumTextStyle,
                                  ),
                                ),
                              ],
                            ),
                            heightSpace,
                            heightSpace,
                            Row(
                              children: [
                                Icon(
                                  Icons.mail,
                                  color: darkBlueColor,
                                  size: 16,
                                ),
                                widthSpace,
                                widthSpace,
                                Text(
                                  'johnsamantha@gmail.com',
                                  style: darkBlueColor11MediumTextStyle,
                                ),
                              ],
                            ),
                            divider(),
                            RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: 'Note: ',
                                    style: greyColorColor9SemiBoldTextStyle,
                                  ),
                                  TextSpan(
                                    text:
                                        'Hi, please pack green sauce in my order and please tell your delivery boy that he have to come on 2nd floor because i’m not at home.',
                                    style: greyColorColor9RegularTextStyle,
                                  ),
                                ],
                              ),
                            ),
                            divider(),
                            orderInformationRow(
                              title: 'Order Items',
                              information1: 'Qnt.',
                              information2: 'Amount',
                              style: darkBlueColor13SemiBoldTextStyle,
                            ),
                            SizedBox(height: 8),
                            orderInformationRow(
                              title: 'Veg Sandwich',
                              information1: '1',
                              information2: '\$6.00',
                              style: darkBlueColor11MediumTextStyle,
                            ),
                            heightSpace,
                            orderInformationRow(
                              title: 'Veg Frankie',
                              information1: '2',
                              information2: '\$20.00',
                              style: darkBlueColor11MediumTextStyle,
                            ),
                            heightSpace,
                            orderInformationRow(
                              title: 'Margherite Pizza',
                              information1: '1',
                              information2: '\$12.00',
                              style: darkBlueColor11MediumTextStyle,
                            ),
                            heightSpace,
                            orderInformationRow(
                              title: 'TotalAmount',
                              information1: '',
                              information2: '\$38.00',
                              style: darkBlueColor11MediumTextStyle,
                            ),
                            SizedBox(height: 7),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  'Service Tax: ',
                                  style: greyColor11MediumTextStyle,
                                ),
                                Text(
                                  '\$2.50',
                                  style: darkBlueColor11MediumTextStyle,
                                ),
                              ],
                            ),
                            SizedBox(height: 2),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.end,
                              children: [
                                Text(
                                  'Delivery Charge: ',
                                  style: greyColor11MediumTextStyle,
                                ),
                                Text(
                                  '\$1.50',
                                  style: darkBlueColor11MediumTextStyle,
                                ),
                              ],
                            ),
                            heightSpace,
                            heightSpace,
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Row(
                                  children: [
                                    Text(
                                      'Order Status: ',
                                      style: darkBlueColor11SemiBoldTextStyle,
                                    ),
                                    Text(
                                      status == 'Order Delivered'
                                          ? status
                                          : 'Order Cancel By User',
                                      style: primaryColor11SemiBoldTextStyle,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            );
          }),
        );
      },
    );
  }

  orderInformationRow({title, information1, information2, style}) {
    return Row(
      children: [
        Expanded(
          flex: 6,
          child: Text(
            title,
            style: style,
          ),
        ),
        Expanded(
          flex: 1,
          child: Text(
            information1,
            textAlign: TextAlign.center,
            style: style,
          ),
        ),
        Expanded(
          flex: 2,
          child: Text(
            information2,
            textAlign: TextAlign.right,
            style: style,
          ),
        ),
      ],
    );
  }

  divider() {
    return Container(
      margin: EdgeInsets.symmetric(vertical: fixPadding * 1.5),
      color: greyColor,
      height: 1.0,
      width: double.infinity,
    );
  }
}
