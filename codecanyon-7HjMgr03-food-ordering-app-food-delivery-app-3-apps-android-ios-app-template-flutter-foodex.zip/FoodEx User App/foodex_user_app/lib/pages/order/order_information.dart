import 'package:foodex_user_app/pages/screen.dart';

class OrderInformation extends StatelessWidget {
  final orderStatusList = [
    {
      'icon': 'assets/icons/done.png',
      'status': 'Order Placed',
      'time': '4:00 pm',
    },
    {
      'icon': 'assets/icons/restaurant_icon.png',
      'status': 'Preparing',
      'time': '4:05 pm',
    },
    {
      'icon': 'assets/icons/ready.png',
      'status': 'Order Ready',
      'time': '4:25 pm',
    },
    {
      'icon': 'assets/icons/transist.png',
      'status': 'In Transist',
      'time': '',
    },
    {
      'icon': 'assets/icons/delivered.png',
      'status': 'Delivered',
      'time': '',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
        title: Text(
          'Order ',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        children: [
          heightSpace,
          heightSpace,
          statusList(context),
          restaurantDetails(),
          orderInformation(),
        ],
      ),
      bottomNavigationBar: trackOrderButton(context),
    );
  }

  statusList(context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.09,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: orderStatusList.length,
        itemBuilder: (context, index) {
          final item = orderStatusList[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(
              index == 0 ? fixPadding * 2.0 : 0.0,
              0.0,
              fixPadding * 2.0,
              0.0,
            ),
            child: Column(
              children: [
                Container(
                  padding: EdgeInsets.all(8.0),
                  decoration: BoxDecoration(
                    color: primaryColor,
                    shape: BoxShape.circle,
                  ),
                  child: Image.asset(
                    item['icon'],
                    color: whiteColor,
                    height: 24,
                    width: 24,
                  ),
                ),
                heightSpace,
                Text(
                  item['status'],
                  style: darkBlueColor9MediumTextStyle,
                ),
                item['time'] != ''
                    ? Text(
                        item['time'],
                        style: primaryColorColor9MediumTextStyle,
                      )
                    : Container(
                        height: 3.0,
                        width: 3.0,
                        margin: EdgeInsets.only(top: 5.0),
                        decoration: BoxDecoration(
                          color: primaryColor,
                          shape: BoxShape.circle,
                        ),
                      ),
              ],
            ),
          );
        },
      ),
    );
  }

  restaurantDetails() {
    return Container(
      margin: EdgeInsets.only(
        top: fixPadding * 3.5,
        bottom: fixPadding * 2.5,
      ),
      padding: EdgeInsets.symmetric(
        horizontal: fixPadding * 2.0,
        vertical: fixPadding * 1.5,
      ),
      color: lightBlueColor,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Marine Rise Restaurant',
            style: darkBlueColor13SemiBoldTextStyle,
          ),
          SizedBox(height: 2),
          Text(
            '1124, Old Church Street, New york, USA',
            style: greyColor10MediumTextStyle,
          ),
        ],
      ),
    );
  }

  orderInformation() {
    return Container(
      margin: EdgeInsets.all(fixPadding * 2.0),
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [
          BoxShadow(
            color: greyColor.withOpacity(0.1),
            spreadRadius: 2.5,
            blurRadius: 2.5,
          ),
        ],
      ),
      child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(fixPadding),
            decoration: BoxDecoration(
              color: greyColor.withOpacity(0.2),
              borderRadius: BorderRadius.only(
                topRight: Radius.circular(10),
                topLeft: Radius.circular(10),
              ),
            ),
            child: orderInformationRow(
              title: 'Order Items',
              information1: 'Qnt.',
              information2: 'Amount',
              style: darkBlueColor16SemiBoldTextStyle,
            ),
          ),
          Container(
            padding: EdgeInsets.symmetric(
              horizontal: fixPadding,
              vertical: fixPadding * 1.5,
            ),
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.only(
                bottomRight: Radius.circular(10),
                bottomLeft: Radius.circular(10),
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                orderInformationRow(
                  title: 'Veg Sandwich',
                  information1: '1',
                  information2: '\$6.00',
                  style: darkBlueColor14MediumTextStyle,
                ),
                heightSpace,
                heightSpace,
                orderInformationRow(
                  title: 'Veg Frankie',
                  information1: '1',
                  information2: '\$10.00',
                  style: darkBlueColor14MediumTextStyle,
                ),
                heightSpace,
                heightSpace,
                orderInformationRow(
                  title: 'Margherite Pizza',
                  information1: '1',
                  information2: '\$12.00',
                  style: darkBlueColor14MediumTextStyle,
                ),
                heightSpace,
                heightSpace,
                orderInformationRow(
                  title: 'TotalAmount',
                  information1: '',
                  information2: '\$28.00',
                  style: darkBlueColor14MediumTextStyle,
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    right: fixPadding * 1.5,
                    top: fixPadding * 1.5,
                  ),
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'Service Tax: ',
                          style: greyColor11RegularTextStyle,
                        ),
                        TextSpan(
                          text: '\$2.50',
                          style: blackColor11RegularTextStyle,
                        )
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    right: fixPadding * 1.5,
                    top: 5.0,
                  ),
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'Delivery Charge: ',
                          style: greyColor11RegularTextStyle,
                        ),
                        TextSpan(
                          text: '\$1.50',
                          style: blackColor11RegularTextStyle,
                        )
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(
                    right: fixPadding * 1.5,
                    top: fixPadding * 1.5,
                  ),
                  child: RichText(
                    text: TextSpan(
                      children: [
                        TextSpan(
                          text: 'Paid Via Credit Card: ',
                          style: darkBlueColor12SemiBoldTextStyle,
                        ),
                        TextSpan(
                          text: '\$32.00',
                          style: primaryColor12SemiBoldTextStyle,
                        )
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  orderInformationRow({title, information1, information2, style}) {
    return Row(
      children: [
        Expanded(
          flex: 6,
          child: Text(
            title,
            style: style,
          ),
        ),
        Expanded(
          flex: 1,
          child: Text(
            information1,
            textAlign: TextAlign.center,
            style: style,
          ),
        ),
        Expanded(
          flex: 2,
          child: Text(
            information2,
            textAlign: TextAlign.center,
            style: style,
          ),
        ),
      ],
    );
  }

  trackOrderButton(context) {
    return Padding(
      padding: EdgeInsets.all(fixPadding * 2.0),
      child: InkWell(
        borderRadius: BorderRadius.circular(10.0),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => TrackOrder()),
        ),
        child: Container(
          height: 50,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: primaryColor,
            borderRadius: BorderRadius.circular(10.0),
            boxShadow: [
              BoxShadow(
                color: primaryColor.withOpacity(0.2),
                spreadRadius: 2.5,
                blurRadius: 2.5,
              ),
            ],
          ),
          child: Text(
            'Track Order',
            style: whiteColor20BoldTextStyle,
          ),
        ),
      ),
    );
  }
}
