import 'package:foodex_user_app/pages/screen.dart';
import 'package:foodex_user_app/widget/column_builder.dart';

class MyOrders extends StatelessWidget {
  final processOrderList = [
    {
      'date': '14 May',
      'restaurantName': 'Marine Rise Restaurant',
      'orderNumber': 'CCA123654',
      'items': '3',
      'price': '32.00',
      'status': 'Preparing',
    },
    {
      'date': '14 May',
      'restaurantName': 'Sevan Star Restaurant',
      'orderNumber': 'FTR145987',
      'items': '2',
      'price': '30.00',
      'status': 'Dispatch',
    },
  ];

  final pastOrderList = [
    {
      'date': '13\nMay',
      'restaurantName': 'Hunger Spot',
      'orderNumber': 'DET146587',
      'items': '3',
      'price': '40.00',
      'status': 'Confirmed',
    },
    {
      'date': '11\nMay',
      'restaurantName': 'Food by Jesica',
      'orderNumber': 'DET158973',
      'items': '4',
      'price': '54.00',
      'status': 'Confirmed',
    },
    {
      'date': '10\nMay',
      'restaurantName': 'Hunger Spot ',
      'orderNumber': 'TYR147896',
      'items': '4',
      'price': '42.00',
      'status': 'Confirmed',
    },
    {
      'date': '9\nMay',
      'restaurantName': 'Marine Rise Restaurant',
      'orderNumber': 'TEQ145632',
      'items': '2',
      'price': '35.00',
      'status': 'Confirmed',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text(
          'My Orders',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(),
        children: [
          title('Orders in process'),
          processOrdersList(),
          title('Past Orders'),
          pastOrdersList(),
        ],
      ),
    );
  }

  title(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: fixPadding * 2.0,
        vertical: fixPadding,
      ),
      child: Text(
        title,
        style: greyColor16SemiBoldTextStyle,
      ),
    );
  }

  processOrdersList() {
    return ColumnBuilder(
      itemCount: processOrderList.length,
      itemBuilder: (context, index) {
        final item = processOrderList[index];
        return Padding(
          padding: const EdgeInsets.fromLTRB(
            fixPadding * 2.0,
            fixPadding,
            fixPadding * 2.0,
            fixPadding,
          ),
          child: InkWell(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => OrderInformation()),
            ),
            child: Container(
              padding: EdgeInsets.all(fixPadding),
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(10),
                boxShadow: [
                  BoxShadow(
                    color: greyColor.withOpacity(0.1),
                    spreadRadius: 2.5,
                    blurRadius: 2.5,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Row(
                    children: [
                      Expanded(
                        flex: 1,
                        child: Container(
                          child: Text(
                            item['date'],
                            textAlign: TextAlign.center,
                            style: primaryColor12SemiBoldTextStyle,
                          ),
                        ),
                      ),
                      divider(),
                      Expanded(
                        flex: 10,
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  item['restaurantName'],
                                  style: darkBlueColor14SemiBoldTextStyle,
                                ),
                                SizedBox(height: 1),
                                Text(
                                  'Order number: ${item['orderNumber']}',
                                  style: greyColor11MediumTextStyle,
                                ),
                                SizedBox(height: 1),
                                Text(
                                  '${item['items']} Items',
                                  style: greyColor11MediumTextStyle,
                                ),
                              ],
                            ),
                            Text(
                              '\$${item['price']}',
                              style: darkBlueColor14SemiBoldTextStyle,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding: EdgeInsets.symmetric(
                      horizontal: fixPadding * 1.5,
                      vertical: 7.0,
                    ),
                    decoration: BoxDecoration(
                      color: item['status'] == 'Preparing'
                          ? primaryColor.withOpacity(0.1)
                          : Colors.green.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      item['status'],
                      style: TextStyle(
                        color: item['status'] == 'Preparing'
                            ? primaryColor
                            : Colors.green,
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  pastOrdersList() {
    return ColumnBuilder(
      itemCount: pastOrderList.length,
      itemBuilder: (context, index) {
        final item = pastOrderList[index];
        return Padding(
          padding: const EdgeInsets.fromLTRB(
            fixPadding * 2.0,
            fixPadding,
            fixPadding * 2.0,
            fixPadding,
          ),
          child: Container(
            padding: EdgeInsets.all(fixPadding),
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Container(
                        child: Text(
                          item['date'],
                          textAlign: TextAlign.center,
                          style: primaryColor12SemiBoldTextStyle,
                        ),
                      ),
                    ),
                    divider(),
                    Expanded(
                      flex: 10,
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                item['restaurantName'],
                                style: darkBlueColor14SemiBoldTextStyle,
                              ),
                              SizedBox(height: 1),
                              Text(
                                'Order number: ${item['orderNumber']}',
                                style: greyColor11MediumTextStyle,
                              ),
                              SizedBox(height: 1),
                              Text(
                                '${item['items']} Items',
                                style: greyColor11MediumTextStyle,
                              ),
                            ],
                          ),
                          Text(
                            '\$${item['price']}',
                            style: darkBlueColor14SemiBoldTextStyle,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                Container(
                  padding: EdgeInsets.symmetric(
                    horizontal: fixPadding * 1.5,
                    vertical: 7.0,
                  ),
                  decoration: BoxDecoration(
                    color: greyColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    item['status'],
                    style: greyColor15SemiBoldTextStyle,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  divider() {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: fixPadding),
      color: greyColor,
      height: 38.0,
      width: 1.5,
    );
  }
}
