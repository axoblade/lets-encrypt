import 'package:foodex_restaurant_app/pages/screen.dart';
import 'package:foodex_restaurant_app/widget/column_builder.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  double height;
  double width;
  bool isFavorite = false;
  String isSelected = 'Fast food';

  final popularList = [
    {
      'image': 'assets/food/food2.png',
      'foodName': 'Veg Cheese Sandwich',
      'price': '7.00'
    },
    {
      'image': 'assets/food/food3.png',
      'foodName': 'Veg Frankie',
      'price': '6.00'
    },
  ];

  final menuList = [
    {'foodType': 'Fast food'},
    {'foodType': 'Starter'},
    {'foodType': 'Main Course'},
    {'foodType': 'Dessert'},
  ];

  final fastFoodList = [
    {
      'image': 'assets/food/food2.png',
      'name': 'Veg Sandwich',
      'price': '6.00',
      'customise': 'Customise',
    },
    {
      'image': 'assets/food/food4.png',
      'name': 'Veg Frankie',
      'price': '10.00',
      'customise': '',
    },
    {
      'image': 'assets/food/food5.png',
      'name': 'Margherite Pizza',
      'price': '12.00',
      'customise': 'Customise',
    },
  ];

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: Stack(
        children: [
          Container(
            height: 200,
            width: double.infinity,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/food/food1.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
          Container(
            height: height,
            padding: EdgeInsets.only(top: fixPadding * 7.0),
            child: ListView(
              physics: BouncingScrollPhysics(
                parent: AlwaysScrollableScrollPhysics(),
              ),
              children: [
                restaurantDetails(),
                title('Most Popular'),
                popularFoodList(),
                heightSpace,
                heightSpace,
                heightSpace,
                heightSpace,
                heightSpace,
                heightSpace,
                menu(),
                fastFoodsList(),
                addButton(),
              ],
            ),
          ),
          shareButton(),
        ],
      ),
    );
  }

  restaurantDetails() {
    return Stack(
      children: [
        Container(
          margin: EdgeInsets.fromLTRB(
            fixPadding * 2.0,
            fixPadding * 3.2,
            fixPadding * 2.0,
            0.0,
          ),
          decoration: BoxDecoration(
            color: lightBlueColor,
            borderRadius: BorderRadius.circular(10.0),
          ),
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.fromLTRB(
                  fixPadding * 1.5,
                  fixPadding,
                  fixPadding,
                  fixPadding,
                ),
                decoration: BoxDecoration(
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(10.0),
                  boxShadow: [
                    BoxShadow(
                      offset: Offset(0, 4),
                      color: greyColor.withOpacity(0.12),
                      spreadRadius: 2.5,
                      blurRadius: 2.5,
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(width: 70),
                        widthSpace,
                        widthSpace,
                        Expanded(
                          child: Text(
                            'Marine Rise Restaurant',
                            overflow: TextOverflow.fade,
                            style: darkBlueColor14SemiBoldTextStyle,
                          ),
                        ),
                        SizedBox(
                          width: 50,
                        ),
                        Text(
                          '4.3',
                          style: primaryColor15SemiBoldTextStyle,
                        ),
                        widthSpace,
                        Icon(
                          Icons.star_rounded,
                          color: primaryColor,
                          size: 18,
                        ),
                      ],
                    ),
                    heightSpace,
                    Text(
                      'Fast food, Italian, Chinese',
                      style: greyColor14MediumTextStyle,
                    ),
                    heightSpace,
                    Row(
                      children: [
                        Icon(
                          Icons.location_on,
                          color: primaryColor,
                          size: 16,
                        ),
                        widthSpace,
                        Text(
                          '2.5 km',
                          style: greyColor13MediumTextStyle,
                        ),
                        widthSpace,
                        verticalDivider(greyColor),
                        widthSpace,
                        Expanded(
                          child: Text(
                            '1124,Church Street, New york, USA',
                            overflow: TextOverflow.ellipsis,
                            style: greyColor13MediumTextStyle,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.all(fixPadding * 1.5),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'About Restaurant',
                      style: darkBlueColor14SemiBoldTextStyle,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: fixPadding * 2.0),
                      child: Text(
                        'Marine rise restaurant sit amet, consectetur adipiscing elit, sed do eiusmod tempor rise sit incididunt labore et dolore....',
                        style: greyColor11RegularTextStyle,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Positioned(
          top: 0.0,
          left: 35.0,
          child: Container(
            height: 70,
            width: 70,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(7.0),
              image: DecorationImage(
                image: AssetImage('assets/restaurants_logo/logo1.png'),
                fit: BoxFit.cover,
              ),
            ),
          ),
        ),
      ],
    );
  }

  title(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        fixPadding * 2.5,
        fixPadding * 2.0,
        fixPadding * 1.5,
      ),
      child: Text(
        title,
        style: darkBlueColor17SemiBoldTextStyle,
      ),
    );
  }

  popularFoodList() {
    return Container(
      height: height * 0.143,
      child: ListView.builder(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        scrollDirection: Axis.horizontal,
        itemCount: popularList.length,
        itemBuilder: (context, index) {
          final item = popularList[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(
              index == 0 ? fixPadding * 2.0 : 0.0,
              0.0,
              fixPadding * 1.5,
              0.0,
            ),
            child: Card(
              color: lightBlueColor,
              elevation: 0.0,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10)),
              child: ClipPath(
                clipper: ShapeBorderClipper(
                  shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10)),
                ),
                child: Column(
                  children: [
                    Container(
                      height: height * 0.10,
                      width: width * 0.51,
                      child: Image.asset(
                        item['image'],
                        fit: BoxFit.cover,
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: fixPadding,
                        vertical: 5.0,
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Text(
                            item['foodName'],
                            style: darkBlueColor12SemiBoldTextStyle,
                          ),
                          widthSpace,
                          verticalDivider(blackColor),
                          widthSpace,
                          Text(
                            '\$${item['price']}',
                            style: primaryColor11SemiBoldTextStyle,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  menu() {
    return Container(
      height: height * 0.04,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: menuList.length,
        itemBuilder: (context, index) {
          final item = menuList[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(
                index == 0 ? fixPadding * 2.0 : fixPadding, 0.0, 0.0, 0.0),
            child: InkWell(
              borderRadius: BorderRadius.circular(15.0),
              onTap: () {
                setState(() {
                  isSelected = item['foodType'];
                });
              },
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: fixPadding),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: isSelected == item['foodType']
                      ? lightBlueColor
                      : Colors.transparent,
                  borderRadius: BorderRadius.circular(15.0),
                ),
                child: Text(
                  item['foodType'],
                  style: TextStyle(
                    color: isSelected == item['foodType']
                        ? darkBlueColor
                        : greyColor,
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  fastFoodsList() {
    return ColumnBuilder(
      itemCount: fastFoodList.length,
      itemBuilder: (context, index) {
        final item = fastFoodList[index];
        return Padding(
          padding: const EdgeInsets.fromLTRB(
            fixPadding * 2.0,
            fixPadding,
            fixPadding * 2.0,
            fixPadding,
          ),
          child: Container(
            padding: EdgeInsets.all(fixPadding),
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Row(
              children: [
                Hero(
                  tag: fastFoodList[index],
                  child: Container(
                    height: height * 0.1,
                    width: width * 0.2,
                    decoration: BoxDecoration(
                      color: greyColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(5.0),
                      image: DecorationImage(
                        image: AssetImage(item['image']),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                ),
                widthSpace,
                widthSpace,
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item['name'],
                        overflow: TextOverflow.ellipsis,
                        style: darkBlueColor15SemiBoldTextStyle,
                      ),
                      heightSpace,
                      Text(
                        '\$${item['price']}',
                        style: darkBlueColor13SemiBoldTextStyle,
                      ),
                      heightSpace,
                      item['customise'] == 'Customise'
                          ? Text(
                              item['customise'],
                              style: primaryColor14MediumTextStyle,
                            )
                          : Container(),
                    ],
                  ),
                ),
                Column(
                  children: [
                    SizedBox(height: 45),
                    Row(
                      children: [
                        InkWell(
                          onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) =>
                                  EditItem(tag: fastFoodList[index]),
                            ),
                          ),
                          child: Container(
                            height: 32.0,
                            width: 32.0,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: primaryColor,
                              borderRadius: BorderRadius.circular(5.0),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.edit,
                                  color: whiteColor,
                                  size: 12,
                                ),
                                Text(
                                  'Edit',
                                  style: whiteColor8MediumTextStyle,
                                ),
                              ],
                            ),
                          ),
                        ),
                        widthSpace,
                        widthSpace,
                        InkWell(
                          onTap: () => deleteDialog(index),
                          child: Container(
                            height: 32.0,
                            width: 32.0,
                            alignment: Alignment.center,
                            decoration: BoxDecoration(
                              color: darkBlueColor,
                              borderRadius: BorderRadius.circular(3.0),
                            ),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.delete,
                                  color: whiteColor,
                                  size: 12,
                                ),
                                Text(
                                  'Delete',
                                  style: whiteColor8MediumTextStyle,
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  deleteDialog(index) {
    showDialog(
      context: context,
      builder: (context) {
        return Dialog(
          backgroundColor: bgColor,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
          insetPadding: EdgeInsets.symmetric(horizontal: fixPadding * 5.0),
          child: Wrap(
            children: [
              Padding(
                padding: const EdgeInsets.all(fixPadding * 1.5),
                child: Column(
                  children: [
                    Text(
                      'Are you sure want to Delete Item?',
                      style: darkBlueColor15SemiBoldTextStyle,
                    ),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    Row(
                      children: [
                        Expanded(
                          child: InkWell(
                            onTap: () => Navigator.pop(context),
                            child: Container(
                              padding: EdgeInsets.all(fixPadding),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                border: Border.all(color: primaryColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Text(
                                'Cancel',
                                style: primaryColor15BoldTextStyle,
                              ),
                            ),
                          ),
                        ),
                        widthSpace,
                        widthSpace,
                        widthSpace,
                        widthSpace,
                        Expanded(
                          child: InkWell(
                            onTap: () {
                              Navigator.pop(context);
                              setState(() {
                                fastFoodList.removeAt(index);
                              });
                            },
                            child: Container(
                              padding: EdgeInsets.all(fixPadding),
                              alignment: Alignment.center,
                              decoration: BoxDecoration(
                                color: primaryColor,
                                border: Border.all(color: primaryColor),
                                borderRadius: BorderRadius.circular(10.0),
                              ),
                              child: Text(
                                'Delete',
                                style: whiteColor15BoldTextStyle,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              )
            ],
          ),
        );
      },
    );
  }

  addButton() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: fixPadding * 4.0,
        vertical: fixPadding * 2.0,
      ),
      child: Row(
        children: [
          Expanded(
            child: InkWell(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddCategory()),
              ),
              child: Container(
                padding: EdgeInsets.all(fixPadding),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  border: Border.all(color: primaryColor),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'Add Category',
                  style: primaryColor15BoldTextStyle,
                ),
              ),
            ),
          ),
          widthSpace,
          widthSpace,
          widthSpace,
          Expanded(
            child: InkWell(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AddItem()),
              ),
              child: Container(
                padding: EdgeInsets.all(fixPadding),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: primaryColor,
                  border: Border.all(color: primaryColor),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'Add New Item',
                  style: whiteColor15BoldTextStyle,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  shareButton() {
    return Positioned(
      top: 60.0,
      right: 20.0,
      child: IconButton(
        onPressed: () {},
        icon: Icon(Icons.share),
        color: whiteColor,
      ),
    );
  }

  verticalDivider(Color color) {
    return Container(
      color: color,
      height: 11.0,
      width: 1.5,
    );
  }
}
