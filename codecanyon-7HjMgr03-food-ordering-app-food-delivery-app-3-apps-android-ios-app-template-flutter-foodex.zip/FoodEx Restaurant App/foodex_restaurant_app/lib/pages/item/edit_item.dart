import 'package:foodex_restaurant_app/pages/screen.dart';

class EditItem extends StatefulWidget {
  final tag;

  const EditItem({Key key, this.tag}) : super(key: key);
  @override
  _EditItemState createState() => _EditItemState();
}

class _EditItemState extends State<EditItem> {
  double height;
  double width;
  String dropdownValue;
  bool veg = true;
  final nameController = TextEditingController(text: 'Sandwich');
  final priceController = TextEditingController(text: '6.0');

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
        title: Text(
          'Edit Item',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: ListView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        children: [
          image(),
          nameTextField(),
          categoryTextField(),
          priceTextField(),
          foodType(),
          addSpecifications(),
          button(),
        ],
      ),
    );
  }

  image() {
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: fixPadding * 2.0,
        vertical: fixPadding,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Change Item Image',
            style: darkBlueColor15SemiBoldTextStyle,
          ),
          heightSpace,
          heightSpace,
          Stack(
            children: [
              Padding(
                padding: const EdgeInsets.only(left: fixPadding * 1.5),
                child: InkWell(
                  onTap: () => changeItemImage(),
                  child: Hero(
                    tag: widget.tag,
                    child: Container(
                      height: height * 0.09,
                      width: width * 0.18,
                      margin: EdgeInsets.only(
                          bottom: fixPadding, right: fixPadding),
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(5.0),
                        boxShadow: [
                          BoxShadow(
                            color: blackColor.withOpacity(0.1),
                            spreadRadius: 1.5,
                            blurRadius: 1.5,
                          ),
                        ],
                        image: DecorationImage(
                          image: AssetImage('assets/food/food2.png'),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 1.0,
                right: 1.0,
                child: InkWell(
                  onTap: () => changeItemImage(),
                  child: Container(
                    decoration: BoxDecoration(
                      color: primaryColor,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      Icons.add,
                      color: whiteColor,
                      size: 20,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  changeItemImage() {
    showModalBottomSheet(
      context: context,
      builder: (BuildContext context) {
        return Container(
          color: bgColor,
          child: Wrap(
            children: <Widget>[
              Container(
                padding: EdgeInsets.all(fixPadding),
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: fixPadding),
                      child: Text(
                        'Choose Option',
                        textAlign: TextAlign.center,
                        style: darkBlueColor14SemiBoldTextStyle,
                      ),
                    ),
                    heightSpace,
                    heightSpace,
                    heightSpace,
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        padding: EdgeInsets.all(10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              Icons.camera_alt,
                              color: darkBlueColor,
                              size: 18.0,
                            ),
                            widthSpace,
                            widthSpace,
                            Text(
                              'Camera',
                              style: darkBlueColor13SemiBoldTextStyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.pop(context);
                      },
                      child: Container(
                        padding: EdgeInsets.all(10.0),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: <Widget>[
                            Icon(
                              Icons.photo_library,
                              color: darkBlueColor,
                              size: 18.0,
                            ),
                            widthSpace,
                            widthSpace,
                            Text(
                              'Select Photo From Gallery',
                              style: darkBlueColor13SemiBoldTextStyle,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        );
      },
    );
  }

  nameTextField() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        0.0,
        fixPadding * 2.0,
        fixPadding * 2.0,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Item Name',
            style: darkBlueColor15SemiBoldTextStyle,
          ),
          heightSpace,
          heightSpace,
          Container(
            height: 42,
            padding: EdgeInsets.symmetric(horizontal: fixPadding),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: TextField(
              controller: nameController,
              cursorColor: primaryColor,
              style: greyColor13SemiBoldTextStyle,
              decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.zero,
                border: UnderlineInputBorder(borderSide: BorderSide.none),
              ),
            ),
          ),
        ],
      ),
    );
  }

  categoryTextField() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        0.0,
        fixPadding * 2.0,
        fixPadding * 2.0,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Item Category',
            style: darkBlueColor15SemiBoldTextStyle,
          ),
          heightSpace,
          heightSpace,
          Container(
            height: 42,
            padding: EdgeInsets.symmetric(horizontal: fixPadding),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: DropdownButtonFormField(
              decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.zero,
                border: InputBorder.none,
              ),
              value: dropdownValue,
              style: greyColor13SemiBoldTextStyle,
              icon: Icon(
                Icons.keyboard_arrow_down,
                color: greyColor,
              ),
              hint: Text(
                'Fast Food',
                style: greyColor13SemiBoldTextStyle,
              ),
              onChanged: (String newValue) {
                setState(() {
                  dropdownValue = newValue;
                });
              },
              items: <String>[
                'Fast Food',
                'Starter',
                'Main Course',
                'Dessert',
              ].map<DropdownMenuItem<String>>((String value) {
                return DropdownMenuItem<String>(
                  value: value,
                  child: Text(value),
                );
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  priceTextField() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        0.0,
        fixPadding * 2.0,
        fixPadding * 2.0,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Item Price',
            style: darkBlueColor15SemiBoldTextStyle,
          ),
          heightSpace,
          heightSpace,
          Container(
            height: 42,
            padding: EdgeInsets.symmetric(horizontal: fixPadding),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Row(
              children: [
                Text(
                  '\$',
                  style: greyColor13SemiBoldTextStyle,
                ),
                Expanded(
                  child: TextField(
                    controller: priceController,
                    cursorColor: primaryColor,
                    style: greyColor13SemiBoldTextStyle,
                    decoration: InputDecoration(
                      isDense: true,
                      contentPadding: EdgeInsets.zero,
                      border: UnderlineInputBorder(borderSide: BorderSide.none),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  foodType() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        0.0,
        fixPadding * 2.0,
        fixPadding * 2.0,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Food Type',
            style: darkBlueColor15SemiBoldTextStyle,
          ),
          heightSpace,
          heightSpace,
          Row(
            children: [
              InkWell(
                onTap: () {
                  setState(() {
                    veg = true;
                  });
                },
                child: Container(
                  height: 42,
                  width: 110.0,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: veg ? primaryColor : whiteColor,
                    borderRadius: BorderRadius.circular(10.0),
                    boxShadow: [
                      BoxShadow(
                        color: veg
                            ? primaryColor.withOpacity(0.1)
                            : greyColor.withOpacity(0.1),
                        spreadRadius: 2.5,
                        blurRadius: 2.5,
                      ),
                    ],
                  ),
                  child: Text(
                    'Veg',
                    style: TextStyle(
                      color: veg ? whiteColor : greyColor,
                      fontSize: 13,
                      fontWeight: veg ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                ),
              ),
              widthSpace,
              widthSpace,
              widthSpace,
              widthSpace,
              InkWell(
                onTap: () {
                  setState(() {
                    veg = false;
                  });
                },
                child: Container(
                  height: 42,
                  width: 110.0,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: veg ? whiteColor : primaryColor,
                    borderRadius: BorderRadius.circular(10.0),
                    boxShadow: [
                      BoxShadow(
                        color: veg
                            ? greyColor.withOpacity(0.1)
                            : primaryColor.withOpacity(0.1),
                        spreadRadius: 2.5,
                        blurRadius: 2.5,
                      ),
                    ],
                  ),
                  child: Text(
                    'Non Veg',
                    style: TextStyle(
                      color: veg ? greyColor : whiteColor,
                      fontSize: 13,
                      fontWeight: !veg ? FontWeight.w600 : FontWeight.w400,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  addSpecifications() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        0.0,
        fixPadding * 2.0,
        fixPadding * 2.0,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Add Specifications',
            style: darkBlueColor15SemiBoldTextStyle,
          ),
          heightSpace,
          heightSpace,
          Container(
            height: 42,
            padding: EdgeInsets.symmetric(horizontal: fixPadding),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 5,
                  child: TextField(
                    cursorColor: primaryColor,
                    style: greyColor13SemiBoldTextStyle,
                    decoration: InputDecoration(
                      isDense: true,
                      contentPadding: EdgeInsets.zero,
                      hintStyle: greyColor13SemiBoldTextStyle,
                      hintText: 'Extra Cheese',
                      border: UnderlineInputBorder(borderSide: BorderSide.none),
                    ),
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        '\$',
                        style: greyColor13SemiBoldTextStyle,
                      ),
                      Expanded(
                        child: TextField(
                          cursorColor: primaryColor,
                          style: greyColor13SemiBoldTextStyle,
                          decoration: InputDecoration(
                            isDense: true,
                            hintStyle: greyColor13SemiBoldTextStyle,
                            hintText: '3.00',
                            contentPadding: EdgeInsets.zero,
                            border: UnderlineInputBorder(
                                borderSide: BorderSide.none),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          heightSpace,
          heightSpace,
          Container(
            height: 42,
            padding: EdgeInsets.symmetric(horizontal: fixPadding),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 5,
                  child: TextField(
                    cursorColor: primaryColor,
                    style: greyColor13SemiBoldTextStyle,
                    decoration: InputDecoration(
                      isDense: true,
                      contentPadding: EdgeInsets.zero,
                      hintStyle: greyColor13SemiBoldTextStyle,
                      hintText: 'Extra Mayonnaise',
                      border: UnderlineInputBorder(borderSide: BorderSide.none),
                    ),
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        '\$',
                        style: greyColor13SemiBoldTextStyle,
                      ),
                      Expanded(
                        child: TextField(
                          cursorColor: primaryColor,
                          style: greyColor13SemiBoldTextStyle,
                          decoration: InputDecoration(
                            isDense: true,
                            hintStyle: greyColor13SemiBoldTextStyle,
                            hintText: '2.00',
                            contentPadding: EdgeInsets.zero,
                            border: UnderlineInputBorder(
                                borderSide: BorderSide.none),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          heightSpace,
          heightSpace,
          Container(
            height: 42,
            padding: EdgeInsets.symmetric(horizontal: fixPadding),
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Row(
              children: [
                Expanded(
                  flex: 5,
                  child: TextField(
                    cursorColor: primaryColor,
                    style: greyColor13SemiBoldTextStyle,
                    decoration: InputDecoration(
                      isDense: true,
                      contentPadding: EdgeInsets.zero,
                      hintStyle: greyColor13SemiBoldTextStyle,
                      hintText: 'Extra Veggies',
                      border: UnderlineInputBorder(borderSide: BorderSide.none),
                    ),
                  ),
                ),
                Expanded(
                  flex: 1,
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      Text(
                        '\$',
                        style: greyColor13SemiBoldTextStyle,
                      ),
                      Expanded(
                        child: TextField(
                          cursorColor: primaryColor,
                          style: greyColor13SemiBoldTextStyle,
                          decoration: InputDecoration(
                            isDense: true,
                            hintStyle: greyColor13SemiBoldTextStyle,
                            hintText: '1.50',
                            contentPadding: EdgeInsets.zero,
                            border: UnderlineInputBorder(
                                borderSide: BorderSide.none),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  button() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 7.0,
        fixPadding,
        fixPadding * 7.0,
        fixPadding * 3.0,
      ),
      child: Row(
        children: [
          Expanded(
            child: InkWell(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: EdgeInsets.all(fixPadding),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  border: Border.all(color: primaryColor),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'Cancel',
                  style: primaryColor15BoldTextStyle,
                ),
              ),
            ),
          ),
          widthSpace,
          widthSpace,
          widthSpace,
          Expanded(
            child: InkWell(
              onTap: () => Navigator.pop(context),
              child: Container(
                padding: EdgeInsets.all(fixPadding),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: primaryColor,
                  border: Border.all(color: primaryColor),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(
                  'Save',
                  style: whiteColor15BoldTextStyle,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
