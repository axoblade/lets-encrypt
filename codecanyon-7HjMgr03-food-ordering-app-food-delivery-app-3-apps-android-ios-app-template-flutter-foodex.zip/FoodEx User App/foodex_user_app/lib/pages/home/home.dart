import 'package:foodex_user_app/pages/screen.dart';
import 'package:foodex_user_app/widget/column_builder.dart';

class Home extends StatefulWidget {
  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  double height;
  double width;

  final foodList = [
    {'image': 'assets/food/food1.png'},
    {'image': 'assets/food/food2.png'},
  ];

  final foodCategoryList = [
    {
      'image': 'assets/food/food3.png',
      'category': 'Fast Food',
    },
    {
      'image': 'assets/food/food4.png',
      'category': 'South Indian',
    },
    {
      'image': 'assets/food/food5.png',
      'category': 'Chienese',
    },
    {
      'image': 'assets/food/food6.png',
      'category': 'Diet Food',
    },
    {
      'image': 'assets/food/food7.png',
      'category': 'Italian',
    },
    {
      'image': 'assets/food/food8.png',
      'category': 'Sea Food',
    },
    {
      'image': 'assets/food/food9.png',
      'category': 'Ice Cream',
    },
    {
      'image': 'assets/food/food10.png',
      'category': 'Dessert',
    },
  ];

  final offerList = [
    {'image': 'assets/offer_banner/Offer1.png'},
    {'image': 'assets/offer_banner/Offer2.png'},
  ];

  final restaurantList = [
    {
      'name': 'Marine Rise Restaurant',
      'rating': '4.3',
      'ratedPeopleCount': '198',
      'address': '1124, Old Church Street, New york, USA',
    },
    {
      'name': 'Sliver Leaf  Restaurant',
      'rating': '4.0',
      'ratedPeopleCount': '170',
      'address': '1124, Old Church Street, New york, USA',
    },
    {
      'name': 'Johson Foods',
      'rating': '3.5',
      'ratedPeopleCount': '130',
      'address': '1124, Old Church Street, New york, USA',
    },
    {
      'name': 'Lepord Cafe',
      'rating': '3.0',
      'ratedPeopleCount': '100',
      'address': '1124, Old Church Street, New york, USA',
    },
    {
      'name': 'King Of Foods',
      'rating': '2.0',
      'ratedPeopleCount': '80',
      'address': '1124, Old Church Street, New york, USA',
    },
  ];

  final todaySpecialList = [
    {
      'image': 'assets/food/food11.png',
      'name': 'Chicken italiano cheezy periperi pizza',
      'price': '14.99',
      'type': 'NonVeg',
    },
    {
      'image': 'assets/food/food14.png',
      'name': 'Paneer Khurchan',
      'price': '19.99',
      'type': 'Veg',
    },
  ];

  @override
  Widget build(BuildContext context) {
    height = MediaQuery.of(context).size.height;
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      body: ListView(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        children: [
          searchTextField(),
          foodsList(),
          title('Food Categories'),
          foodsCategoryList(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              title('Offers For You'),
              Padding(
                padding: const EdgeInsets.only(right: fixPadding * 2.0),
                child: Text(
                  'see all',
                  style: primaryColor12MediumTextStyle,
                ),
              ),
            ],
          ),
          offersList(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              title('Restaurants Near You'),
              InkWell(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => AllRestaurants()),
                ),
                child: Padding(
                  padding: const EdgeInsets.only(right: fixPadding * 2.0),
                  child: Text(
                    'see all',
                    style: primaryColor12MediumTextStyle,
                  ),
                ),
              ),
            ],
          ),
          restaurantsList(),
          title('Today\'s Special'),
          todaysSpecialList(),
        ],
      ),
    );
  }

  searchTextField() {
    return Padding(
      padding: EdgeInsets.all(fixPadding * 2.0),
      child: InkWell(
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => Search()),
        ),
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: whiteColor,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: greyColor.withOpacity(0.1),
                spreadRadius: 2.5,
                blurRadius: 2.5,
              ),
            ],
          ),
          child: TextField(
            enabled: false,
            cursorColor: primaryColor,
            decoration: InputDecoration(
              prefixIcon: Icon(
                Icons.search,
                color: Colors.blueGrey[800],
                size: 20,
              ),
              hintText: 'Search for restaurant,food...',
              hintStyle: greyColor14MediumTextStyle,
              border: UnderlineInputBorder(borderSide: BorderSide.none),
            ),
          ),
        ),
      ),
    );
  }

  foodsList() {
    return Container(
      height: height * 0.15,
      child: ListView.builder(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        scrollDirection: Axis.horizontal,
        itemCount: foodList.length,
        itemBuilder: (context, index) {
          final item = foodList[index];
          return Padding(
            padding: EdgeInsets.fromLTRB(
                index == 0 ? fixPadding * 2.0 : fixPadding,
                0.0,
                index == foodList.length - 1 ? fixPadding * 2.0 : fixPadding,
                0.0),
            child: Container(
              height: height * 0.15,
              width: 200,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                image: DecorationImage(
                  image: AssetImage(item['image']),
                  fit: BoxFit.cover,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  title(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        fixPadding * 2.0,
        fixPadding * 2.0,
        fixPadding,
      ),
      child: Text(
        title,
        style: darkBlueColor17SemiBoldTextStyle,
      ),
    );
  }

  foodsCategoryList() {
    return Container(
      height: height * 0.12,
      child: ListView.builder(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        scrollDirection: Axis.horizontal,
        itemCount: foodCategoryList.length,
        itemBuilder: (context, index) {
          final item = foodCategoryList[index];
          return Padding(
            padding: EdgeInsets.only(
              left: index == 0 ? fixPadding * 2.0 : 0.0,
              right: index == foodCategoryList.length - 1
                  ? fixPadding * 2.0
                  : fixPadding * 1.5,
            ),
            child: InkWell(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => AllRestaurants()),
              ),
              child: Column(
                children: [
                  Container(
                    height: height * 0.09,
                    width: width * 0.18,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      image: DecorationImage(
                        image: AssetImage(item['image']),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  heightSpace,
                  Text(
                    item['category'],
                    style: darkBlueColor11SemiBoldTextStyle,
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  offersList() {
    return Container(
      height: height * 0.15,
      child: ListView.builder(
        physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
        scrollDirection: Axis.horizontal,
        itemCount: offerList.length,
        itemBuilder: (context, index) {
          final item = offerList[index];
          return Padding(
            padding: EdgeInsets.only(
              left: index == 0 ? fixPadding * 2.0 : 0.0,
              right: index == foodCategoryList.length - 1
                  ? fixPadding * 2.0
                  : fixPadding * 1.5,
            ),
            child: InkWell(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => ParticularItem(
                    tag: offerList[index],
                  ),
                ),
              ),
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 5.0),
                height: height * 0.10,
                width: width * 0.62,
                padding: EdgeInsets.all(fixPadding),
                decoration: BoxDecoration(
                  color: whiteColor,
                  borderRadius: BorderRadius.circular(10),
                  boxShadow: [
                    BoxShadow(
                      color: greyColor.withOpacity(0.1),
                      spreadRadius: 2.5,
                      blurRadius: 2.5,
                    ),
                  ],
                ),
                child: Hero(
                  tag: offerList[index],
                  child: Image.asset(
                    item['image'],
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  restaurantsList() {
    return ColumnBuilder(
      itemCount: restaurantList.length,
      itemBuilder: (context, index) {
        final item = restaurantList[index];
        return Padding(
          padding: EdgeInsets.fromLTRB(
              fixPadding * 2.0, 0.0, fixPadding * 2.0, fixPadding * 2.0),
          child: InkWell(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) =>
                    RestaurantDetails(tag: restaurantList[index]),
              ),
            ),
            child: Container(
              padding: EdgeInsets.all(fixPadding),
              decoration: BoxDecoration(
                color: whiteColor,
                borderRadius: BorderRadius.circular(10.0),
                boxShadow: [
                  BoxShadow(
                    color: greyColor.withOpacity(0.1),
                    spreadRadius: 2.5,
                    blurRadius: 2.5,
                  ),
                ],
              ),
              child: Column(
                children: [
                  Row(
                    children: [
                      Hero(
                        tag: restaurantList[index],
                        child: Container(
                          padding: EdgeInsets.all(5.0),
                          decoration: BoxDecoration(
                            color: Color(0xffe6e6e6),
                            borderRadius: BorderRadius.circular(5.0),
                          ),
                          child: Image.asset(
                            'assets/icons/restaurant_icon.png',
                            height: 25,
                            width: 25,
                          ),
                        ),
                      ),
                      widthSpace,
                      widthSpace,
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  item['name'],
                                  style: darkBlueColor13SemiBoldTextStyle,
                                ),
                                Row(
                                  children: [
                                    Text(
                                      item['rating'],
                                      style: primaryColor12SemiBoldTextStyle,
                                    ),
                                    widthSpace,
                                    Icon(
                                      Icons.star,
                                      color: primaryColor,
                                      size: 15,
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            Text(
                              '${item['ratedPeopleCount']} People Rated',
                              style: greyColor13MediumTextStyle,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  heightSpace,
                  Row(
                    children: [
                      widthSpace,
                      widthSpace,
                      Icon(
                        Icons.location_on,
                        color: primaryColor,
                        size: 15,
                      ),
                      widthSpace,
                      Text(
                        item['address'],
                        style: greyColor12MediumTextStyle,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  todaysSpecialList() {
    return ColumnBuilder(
      itemCount: todaySpecialList.length,
      itemBuilder: (context, index) {
        final item = todaySpecialList[index];
        return Padding(
          padding: const EdgeInsets.fromLTRB(
            fixPadding * 2.0,
            0.0,
            fixPadding * 2.0,
            fixPadding,
          ),
          child: InkWell(
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ParticularItem(
                  tag: todaySpecialList[index],
                  image: item['image'],
                  name: item['name'],
                  price: item['price'],
                  foodType: item['foodType'],
                ),
              ),
            ),
            child: Stack(
              children: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                  ),
                  child: Column(
                    children: [
                      Hero(
                        tag: todaySpecialList[index],
                        child: Container(
                          height: height * 0.16,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(10),
                              topRight: Radius.circular(10.0),
                            ),
                            image: DecorationImage(
                              image: AssetImage(item['image']),
                              fit: BoxFit.cover,
                            ),
                          ),
                        ),
                      ),
                      Container(
                        height: height * 0.07,
                        width: double.infinity,
                        padding: EdgeInsets.all(fixPadding),
                        decoration: BoxDecoration(
                          color: lightBlueColor,
                          borderRadius: BorderRadius.only(
                            bottomLeft: Radius.circular(10),
                            bottomRight: Radius.circular(10.0),
                          ),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                  right: fixPadding * 12.0),
                              child: Text(
                                item['name'],
                                style: darkBlueColor14MediumTextStyle,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
                Positioned(
                  top: 5.0,
                  right: 5.0,
                  child: Text(
                    '${item['price']}\$',
                    style: whiteColor15BoldTextStyle,
                  ),
                ),
                Positioned(
                  right: 10.0,
                  bottom: 20,
                  child: Container(
                    padding: EdgeInsets.all(2.0),
                    decoration: BoxDecoration(
                      color: Colors.transparent,
                      border: Border.all(
                          color: item['type'] == 'Veg'
                              ? Colors.green
                              : Colors.red),
                    ),
                    child: Container(
                      height: 6.0,
                      width: 6.0,
                      decoration: BoxDecoration(
                        color:
                            item['type'] == 'Veg' ? Colors.green : Colors.red,
                        shape: BoxShape.circle,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
