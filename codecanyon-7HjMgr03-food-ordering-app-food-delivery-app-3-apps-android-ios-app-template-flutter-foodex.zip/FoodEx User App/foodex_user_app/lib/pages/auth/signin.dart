import 'package:foodex_user_app/pages/screen.dart';

class SignIn extends StatefulWidget {
  @override
  _SignInState createState() => _SignInState();
}

class _SignInState extends State<SignIn> {
  bool visible = false;
  double width;

  @override
  Widget build(BuildContext context) {
    width = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(
        leading: IconButton(
          onPressed: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => SplashScreen()),
          ),
          icon: Icon(Icons.arrow_back_ios),
        ),
      ),
      body: Stack(
        children: [
          cornerImage(),
          ListView(
            physics:
                BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
            children: [
              heightSpace,
              heightSpace,
              Padding(
                padding: const EdgeInsets.fromLTRB(fixPadding * 2.0, fixPadding,
                    fixPadding * 2.0, fixPadding * 2.0),
                child: Text(
                  'Sign In',
                  style: darkBlueColor22BoldTextStyle,
                ),
              ),
              userNameTextField(),
              passwordTextField(),
              signinButton(),
              otherSigninOptions(),
            ],
          ),
        ],
      ),
    );
  }

  userNameTextField() {
    return Container(
      margin: EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        fixPadding,
        fixPadding * 2.0,
        fixPadding * 2.0,
      ),
      padding: EdgeInsets.all(fixPadding * 1.5),
      decoration: BoxDecoration(
        color: whiteColor,
        borderRadius: BorderRadius.circular(10.0),
        boxShadow: [
          BoxShadow(
            color: greyColor.withOpacity(0.1),
            spreadRadius: 2.5,
            blurRadius: 2.5,
          ),
        ],
      ),
      child: Row(
        children: [
          Icon(
            Icons.person_outline,
            color: greyColor,
            size: 20,
          ),
          widthSpace,
          Expanded(
            child: TextField(
              cursorColor: primaryColor,
              style: greyColor16MediumTextStyle,
              keyboardType: TextInputType.name,
              decoration: InputDecoration(
                isDense: true,
                contentPadding: EdgeInsets.zero,
                hintStyle: greyColor16MediumTextStyle,
                hintText: 'User Name',
                border: UnderlineInputBorder(borderSide: BorderSide.none),
              ),
            ),
          ),
        ],
      ),
    );
  }

  passwordTextField() {
    return Padding(
      padding: EdgeInsets.fromLTRB(
        fixPadding * 2.0,
        0.0,
        fixPadding * 2.0,
        0.0,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          Container(
            padding: EdgeInsets.all(fixPadding * 1.5),
            decoration: BoxDecoration(
              color: whiteColor,
              borderRadius: BorderRadius.circular(10.0),
              boxShadow: [
                BoxShadow(
                  color: greyColor.withOpacity(0.1),
                  spreadRadius: 2.5,
                  blurRadius: 2.5,
                ),
              ],
            ),
            child: Row(
              children: [
                Icon(
                  Icons.lock_outline,
                  color: greyColor,
                  size: 20,
                ),
                widthSpace,
                Expanded(
                  child: TextField(
                    obscureText: !visible,
                    cursorColor: primaryColor,
                    style: greyColor16MediumTextStyle,
                    decoration: InputDecoration(
                      isDense: true,
                      contentPadding: EdgeInsets.zero,
                      hintStyle: greyColor16MediumTextStyle,
                      hintText: 'Password',
                      border: UnderlineInputBorder(borderSide: BorderSide.none),
                    ),
                  ),
                ),
                InkWell(
                  onTap: () {
                    setState(() {
                      visible = !visible;
                    });
                  },
                  child: Icon(
                    visible
                        ? Icons.visibility_outlined
                        : Icons.visibility_off_outlined,
                    color: greyColor,
                    size: 15,
                  ),
                ),
                widthSpace,
              ],
            ),
          ),
          Text(
            'Forget Password?',
            style: greyColor11MediumTextStyle,
          ),
        ],
      ),
    );
  }

  signinButton() {
    return Padding(
      padding: EdgeInsets.symmetric(
        horizontal: fixPadding * 2.0,
        vertical: fixPadding * 1.5,
      ),
      child: InkWell(
        borderRadius: BorderRadius.circular(10.0),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => SignUp()),
        ),
        child: Container(
          height: 50,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: primaryColor,
            borderRadius: BorderRadius.circular(10.0),
            boxShadow: [
              BoxShadow(
                color: primaryColor.withOpacity(0.2),
                spreadRadius: 2.5,
                blurRadius: 2.5,
              ),
            ],
          ),
          child: Text(
            'Sign In',
            style: whiteColor20BoldTextStyle,
          ),
        ),
      ),
    );
  }

  otherSigninOptions() {
    return Column(
      children: [
        Row(
          children: [
            divider(),
            widthSpace,
            widthSpace,
            Text(
              'Or Connect with',
              style: greyColor15MediumTextStyle,
            ),
            widthSpace,
            widthSpace,
            divider(),
          ],
        ),
        heightSpace,
        heightSpace,
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: EdgeInsets.all(10.0),
              decoration: BoxDecoration(
                color: Color(0xff1da1f2),
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                'assets/icons/twitter_icon.png',
                height: 16,
                width: 16,
              ),
            ),
            widthSpace,
            Container(
              padding: EdgeInsets.all(10.0),
              decoration: BoxDecoration(
                color: Color(0xffea4335),
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                'assets/icons/google+_icon.png',
                height: 16,
                width: 25,
              ),
            ),
            widthSpace,
            Container(
              padding: EdgeInsets.all(10.0),
              decoration: BoxDecoration(
                color: Color(0xff4267b2),
                shape: BoxShape.circle,
              ),
              child: Image.asset(
                'assets/icons/facebook_icon.png',
                height: 16,
                width: 16,
              ),
            ),
          ],
        ),
        heightSpace,
        heightSpace,
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              'Don\'t have an account? ',
              style: greyColor15MediumTextStyle,
            ),
            InkWell(
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => SignUp()),
              ),
              child: Text(
                'Sign Up',
                style: darkBlueColor15MediumTextStyle,
              ),
            ),
          ],
        ),
      ],
    );
  }

  divider() {
    return Expanded(
      child: Container(
        color: greyColor,
        height: 1.0,
      ),
    );
  }

  cornerImage() {
    return Positioned(
      bottom: 0.0,
      left: 0.0,
      child: Image.asset(
        'assets/bg1.png',
        height: 170.0,
        width: 170.0,
        fit: BoxFit.cover,
      ),
    );
  }
}
