import 'package:foodex_restaurant_app/pages/screen.dart';

class Reviews extends StatelessWidget {
  final reviewList = [
    {
      'image': 'assets/users/user1.png',
      'name': 'George Smith',
      'date': 'June 25, 2020',
      'rating': 4,
      'review':
          'Marine rise restaurant sit amet, consectetur adipiscing elit, sed do eiusmod tempor rise sit.....',
    },
    {
      'image': 'assets/users/user2.png',
      'name': 'Grecy John',
      'date': 'June 28, 2020',
      'rating': 3,
      'review':
          'Marine rise restaurant sit amet, consectetur adipiscing elit, sed do eiusmod tempor rise sit.....',
    },
    {
      'image': 'assets/users/user4.png',
      'name': 'George Smith',
      'date': 'May 28, 2020',
      'rating': 5,
      'review':
          'Marine rise restaurant sit amet, consectetur adipiscing elit, sed do eiusmod tempor rise sit.....',
    },
    {
      'image': 'assets/users/user3.png',
      'name': 'Grecy John',
      'date': 'May 25, 2020',
      'rating': 2,
      'review':
          'Marine rise restaurant sit amet, consectetur adipiscing elit, sed do eiusmod tempor rise sit.....',
    },
    {
      'image': 'assets/users/user6.png',
      'name': 'George Smith',
      'date': 'May 22, 2020',
      'rating': 4,
      'review':
          'Marine rise restaurant sit amet, consectetur adipiscing elit, sed do eiusmod tempor rise sit.....',
    },
    {
      'image': 'assets/users/user5.png',
      'name': 'Grecy John',
      'date': 'May 20, 2020',
      'rating': 3,
      'review':
          'Marine rise restaurant sit amet, consectetur adipiscing elit, sed do eiusmod tempor rise sit.....',
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0.0,
        leading: IconButton(
          onPressed: () => Navigator.pop(context),
          icon: Icon(Icons.arrow_back_ios),
        ),
        title: Text(
          'Reviews',
          style: darkBlueColor18SemiBoldTextStyle,
        ),
      ),
      body: reviewsList(),
    );
  }

  reviewsList() {
    return ListView.builder(
      physics: BouncingScrollPhysics(parent: AlwaysScrollableScrollPhysics()),
      itemCount: reviewList.length,
      itemBuilder: (context, index) {
        final item = reviewList[index];
        return Container(
          margin: EdgeInsets.fromLTRB(
            fixPadding * 2.0,
            fixPadding,
            fixPadding * 2.0,
            fixPadding,
          ),
          padding: EdgeInsets.fromLTRB(
            fixPadding * 1.5,
            fixPadding / 2,
            fixPadding / 2,
            fixPadding * 1.5,
          ),
          decoration: BoxDecoration(
            color: whiteColor,
            borderRadius: BorderRadius.circular(10),
            boxShadow: [
              BoxShadow(
                color: greyColor.withOpacity(0.1),
                spreadRadius: 2.5,
                blurRadius: 2.5,
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    height: 60.0,
                    width: 60.0,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      image: DecorationImage(
                        image: AssetImage(item['image']),
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  widthSpace,
                  widthSpace,
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            ratingStars(item['rating']),
                          ],
                        ),
                        Text(
                          item['name'],
                          style: darkBlueColor14SemiBoldTextStyle,
                        ),
                        SizedBox(
                          height: 2.0,
                        ),
                        Text(
                          item['date'],
                          style: greyColor11MediumTextStyle,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              heightSpace,
              Text(
                item['review'],
                style: greyColor11MediumTextStyle,
              ),
            ],
          ),
        );
      },
    );
  }

  ratingStars(int rating) {
    return Row(
      children: [
        (rating == 5 ||
                rating == 4 ||
                rating == 3 ||
                rating == 2 ||
                rating == 1)
            ? Icon(Icons.star_rounded, color: primaryColor, size: 16)
            : Icon(Icons.star_rounded, color: greyColor, size: 16),
        (rating == 5 || rating == 4 || rating == 3 || rating == 2)
            ? Icon(Icons.star_rounded, color: primaryColor, size: 16)
            : Icon(Icons.star_rounded, color: greyColor, size: 16),
        (rating == 5 || rating == 4 || rating == 3)
            ? Icon(Icons.star_rounded, color: primaryColor, size: 16)
            : Icon(Icons.star_rounded, color: greyColor, size: 16),
        (rating == 5 || rating == 4)
            ? Icon(Icons.star_rounded, color: primaryColor, size: 16)
            : Icon(Icons.star_rounded, color: greyColor, size: 16),
        (rating == 5)
            ? Icon(Icons.star_rounded, color: primaryColor, size: 16)
            : Icon(Icons.star_rounded, color: greyColor, size: 16),
      ],
    );
  }
}
